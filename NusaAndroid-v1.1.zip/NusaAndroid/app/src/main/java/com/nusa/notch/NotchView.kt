package com.nusa.notch

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Outline
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/** Wadah notch: ukuran layout-nya stabil, bentuk yang terlihat di-clip lewat outline (tanpa relayout per frame). */
private class NotchBox(c: Context) : FrameLayout(c) {
    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        invalidateOutline()
    }
}

/**
 * "Notch" yang melayang di tengah-atas layar.
 * COMPACT : pil kecil (maskot / album art + equalizer / timer)
 * ALERT   : melebar sebentar untuk notifikasi (baterai, jaringan, bluetooth, timer, air, notif app)
 * PANEL   : ketuk pil -> kartu penuh. Tab Music = kartu ala video Nusa (cover, progress, kontrol, lirik).
 *
 * Kenapa mulus:
 *  - Bentuk (lebar, tinggi, radius) digerakkan spring fisika per frame layar (Choreographer),
 *    jadi interupsi di tengah animasi tetap nyambung (kecepatan terbawa) dan ada sedikit "membal".
 *  - Yang berubah per frame cuma outline clip (RenderThread), TIDAK ada measure/layout.
 *  - Isi (compact / alert / panel) cuma cross-fade + scale kecil.
 */
@SuppressLint("ViewConstructor", "ClickableViewAccessibility")
class NotchView(private val svc: NotchService, private val media: MediaWatcher) : FrameLayout(svc) {
    enum class S { COMPACT, ALERT, PANEL }

    private val ui = Handler(Looper.getMainLooper())
    var state = S.COMPACT
        private set

    private val box = NotchBox(svc)
    private val tintView = View(svc)
    private val tintBg = GradientDrawable()
    private var shownTint = C.BLACK
    private var tintAnim: ValueAnimator? = null

    private val compact = LinearLayout(svc)
    private val alertBox = LinearLayout(svc)
    private val panelBox = LinearLayout(svc)
    private var shown: View = compact

    // --- bentuk (spring)
    private val sw = Spring(0f, 400f, 0.80f)
    private val sh = Spring(0f, 340f, 0.78f)
    private val sr = Spring(0f, 520f, 0.90f)
    private var curW = 0f
    private var curH = 0f
    private var curR = 0f
    private val choreo = Choreographer.getInstance()
    private var ticking = false
    private var lastNs = 0L
    private val frameCb = Choreographer.FrameCallback { ns -> onFrame(ns) }

    // --- compact
    private val pet = PetView(svc)
    private val miniArt = ImageView(svc)
    private val gap = View(svc)
    private val cText = svc.tv("", 13f, C.TEXT, true)
    private val eq = EqView(svc)
    private var lastMiniArt: Bitmap? = null

    // --- alert
    private val aIconBox = FrameLayout(svc)
    private val aGlyph = svc.tv("", 18f, C.TEXT, true)
    private val aImg = ImageView(svc)
    private val aTitle = svc.tv("", 15f, C.TEXT, true)
    private val aSub = svc.tv("", 13f, C.SUB)
    private var current: Alert? = null
    private val queue = java.util.ArrayDeque<Alert>()

    // --- panel
    private val tabsRow = LinearLayout(svc)
    private val body = FrameLayout(svc)
    private val music = MusicPanel(svc, media)
    private val timer = TimerPanel(svc)
    private val todo = TodoPanel(svc)
    private val water = WaterPanel(svc)
    private val shelf = ShelfPanel(svc)
    private val panels: List<View> = listOf(music, timer, todo, water, shelf)
    private val tabNames = listOf("♪ Music", "⏱ Timer", "✓ Todo", "💧 Water", "📁 Shelf")
    private val tabViews = ArrayList<TextView>()
    private var tab = 0
    private var pw = 0

    private var downX = 0f
    private var downY = 0f

    private val endAlert = Runnable {
        current = null
        val n = queue.poll()
        if (n != null) showAlert(n) else showCompact()
    }

    private val uiTick = object : Runnable {
        override fun run() {
            when (state) {
                S.COMPACT -> {
                    updateCompact()
                    fitCompact()
                }
                S.PANEL -> (panels[tab] as Refreshable).refresh()
                S.ALERT -> {
                }
            }
            ui.postDelayed(this, 500)
        }
    }

    init {
        // ---------- wadah + clip berbentuk (outline) ----------
        box.setBackgroundColor(C.BLACK)
        box.clipChildren = true
        box.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                val vw = view.width.toFloat()
                val w = Math.max(1f, Math.min(curW, vw))
                val h = Math.max(1f, Math.min(curH, view.height.toFloat()))
                val l = Math.round((vw - w) / 2f)
                val r = Math.round((vw + w) / 2f)
                val rad = Math.max(0f, Math.min(curR, Math.min(w, h) / 2f))
                outline.setRoundRect(l, 0, r, Math.round(h), rad)
            }
        }
        box.clipToOutline = true

        // lapisan warna cover (di bawah isi, di atas hitam)
        tintBg.orientation = GradientDrawable.Orientation.TL_BR
        setTintColors(C.BLACK)
        tintView.background = tintBg
        tintView.alpha = 0f
        box.addView(tintView, LayoutParams(MATCH, MATCH))

        // ---------- compact
        compact.orientation = LinearLayout.HORIZONTAL
        compact.gravity = Gravity.CENTER_VERTICAL
        compact.setPadding(svc.dp(10), 0, svc.dp(10), 0)
        compact.addView(pet, LinearLayout.LayoutParams(svc.dp(22), svc.dp(22)))
        miniArt.scaleType = ImageView.ScaleType.CENTER_CROP
        miniArt.roundClip(svc.dpf(6))
        compact.addView(miniArt, LinearLayout.LayoutParams(svc.dp(22), svc.dp(22)))
        compact.addView(gap, LinearLayout.LayoutParams(svc.dp(34), 1))
        cText.minWidth = svc.dp(42)
        compact.addView(cText)
        compact.addView(eq, LinearLayout.LayoutParams(svc.dp(18), svc.dp(14)))
        compact.setOnClickListener {
            showPanel(if (media.hasSession && media.playing) 0 else Nusa.prefs.lastTab)
        }
        compact.pressScale(0.92f)
        box.addView(compact, LayoutParams(WRAP, svc.dp(34), Gravity.TOP or Gravity.CENTER_HORIZONTAL))

        // ---------- alert
        alertBox.orientation = LinearLayout.HORIZONTAL
        alertBox.gravity = Gravity.CENTER_VERTICAL
        alertBox.setPadding(svc.dp(14), 0, svc.dp(18), 0)
        aGlyph.gravity = Gravity.CENTER
        aIconBox.addView(aGlyph, LayoutParams(MATCH, MATCH))
        aImg.scaleType = ImageView.ScaleType.FIT_CENTER
        aImg.roundClip(svc.dpf(10))
        aIconBox.addView(aImg, LayoutParams(MATCH, MATCH))
        alertBox.addView(aIconBox, svc.llp(svc.dp(40), svc.dp(40)))
        val tcol = LinearLayout(svc)
        tcol.orientation = LinearLayout.VERTICAL
        aTitle.maxLines = 1
        aTitle.ellipsize = TextUtils.TruncateAt.END
        aSub.maxLines = 1
        aSub.ellipsize = TextUtils.TruncateAt.END
        tcol.addView(aTitle)
        tcol.addView(aSub, svc.llp(WRAP, WRAP, 0f, 0, 3, 0, 0))
        alertBox.addView(tcol, svc.llp(0, WRAP, 1f, 12, 0, 0, 0))
        alertBox.setOnClickListener {
            val a = current
            ui.removeCallbacks(endAlert)
            queue.clear()
            current = null
            a?.onClick?.invoke()
            if (a != null && a.tab >= 0) showPanel(a.tab) else showCompact()
        }
        alertBox.alpha = 0f
        alertBox.visibility = INVISIBLE
        box.addView(alertBox, LayoutParams(svc.dp(380), svc.dp(68), Gravity.TOP or Gravity.CENTER_HORIZONTAL))

        // ---------- panel
        panelBox.orientation = LinearLayout.VERTICAL
        tabsRow.orientation = LinearLayout.HORIZONTAL
        tabsRow.gravity = Gravity.CENTER_VERTICAL
        tabsRow.setPadding(svc.dp(12), 0, svc.dp(8), 0)
        for (i in tabNames.indices) {
            val t = svc.tv(tabNames[i], 13f, C.SUB, true)
            t.gravity = Gravity.CENTER
            t.setPadding(svc.dp(6), svc.dp(8), svc.dp(6), svc.dp(8))
            t.setOnClickListener { switchTab(i) }
            tabViews.add(t)
            tabsRow.addView(t, svc.llp(0, WRAP, 1f, 2, 0, 2, 0))
        }
        val close = svc.tv("⌃", 18f, C.SUB, true)
        close.setPadding(svc.dp(12), svc.dp(2), svc.dp(10), svc.dp(2))
        close.setOnClickListener { showCompact() }
        tabsRow.addView(close)
        panelBox.addView(tabsRow, svc.llp(MATCH, tabsH()))
        body.setPadding(svc.dp(18), svc.dp(4), svc.dp(18), svc.dp(14))
        for (p in panels) body.addView(p, LayoutParams(MATCH, MATCH))
        panelBox.addView(body, svc.llp(MATCH, bodyH(0)))
        panelBox.alpha = 0f
        panelBox.visibility = INVISIBLE
        box.addView(panelBox, LayoutParams(svc.dp(560), panelH(0), Gravity.TOP or Gravity.CENTER_HORIZONTAL))

        music.onTint = { updateTint() }

        // ukuran awal = pil compact, tanpa animasi
        updateCompact()
        val (cw, ch) = compactSize()
        setCompactHeight(ch)
        sw.snap(cw.toFloat())
        sh.snap(ch.toFloat())
        sr.snap(ch / 2f)
        curW = sw.value
        curH = sh.value
        curR = sr.value
        addView(box, LayoutParams(cw, ch, Gravity.TOP or Gravity.CENTER_HORIZONTAL))
    }

    // ------------------------------------------------------------ util

    private fun screenW(): Int {
        return if (Build.VERSION.SDK_INT >= 30) {
            (svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager).currentWindowMetrics.bounds.width()
        } else {
            resources.displayMetrics.widthPixels
        }
    }

    private fun tabsH(): Int = svc.dp(40)
    private fun bodyH(t: Int): Int = svc.dp(if (t == 0) 166 else 242)
    private fun panelH(t: Int): Int = tabsH() + bodyH(t)

    private fun darken(c: Int, f: Float): Int {
        val r = (((c shr 16) and 255) * f).toInt()
        val g = (((c shr 8) and 255) * f).toInt()
        val b = ((c and 255) * f).toInt()
        return (0xFF shl 24) or (r shl 16) or (g shl 8) or b
    }

    // ------------------------------------------------------------ mesin animasi bentuk

    private fun moving(): Boolean = !(sw.atRest && sh.atRest && sr.atRest)

    private fun applyShape() {
        curW = sw.value
        curH = sh.value
        curR = sr.value
        box.invalidateOutline()
    }

    private fun setBoxSize(w: Int, h: Int) {
        val lp = box.layoutParams
        if (lp.width == w && lp.height == h) return
        lp.width = w
        lp.height = h
        box.layoutParams = lp
    }

    /** Arahkan bentuk ke ukuran baru. Spring meneruskan posisi + kecepatan sekarang (interupsi mulus). */
    private fun morphTo(w: Float, h: Float, r: Float) {
        sw.target = w
        sh.target = h
        sr.target = r
        // jendela harus cukup besar untuk bentuk sekarang + target + sedikit ruang "membal"
        val pad = svc.dp(14)
        setBoxSize(
            Math.ceil(Math.max(w, sw.value).toDouble()).toInt() + pad,
            Math.ceil(Math.max(h, sh.value).toDouble()).toInt() + pad
        )
        kick()
    }

    private fun onSettled() {
        // jendela dipepetkan lagi ke bentuk akhir supaya area di bawah/samping notch bisa disentuh
        setBoxSize(Math.ceil(sw.target.toDouble()).toInt(), Math.ceil(sh.target.toDouble()).toInt())
    }

    private fun kick() {
        if (ticking || !isAttachedToWindow) return
        ticking = true
        lastNs = 0L
        choreo.postFrameCallback(frameCb)
    }

    private fun onFrame(ns: Long) {
        val dt = if (lastNs == 0L) 0.008f else (ns - lastNs) / 1_000_000_000f
        lastNs = ns
        var again = false
        if (moving()) {
            sw.step(dt)
            sh.step(dt)
            sr.step(dt)
            if (!moving()) {
                sw.snap(sw.target)
                sh.snap(sh.target)
                sr.snap(sr.target)
                applyShape()
                onSettled()
            } else {
                applyShape()
                again = true
            }
        }
        if (state == S.PANEL && tab == 0 && music.frame()) again = true
        if (again && isAttachedToWindow) {
            choreo.postFrameCallback(frameCb)
        } else {
            ticking = false
        }
    }

    // ------------------------------------------------------------ cross-fade isi

    private fun crossTo(v: View) {
        shown = v
        for (x in listOf(compact, alertBox, panelBox)) {
            x.animate().cancel()
            if (x === v) {
                if (x.visibility != VISIBLE) {
                    x.alpha = 0f
                    if (x !== compact) {
                        x.pivotX = x.layoutParams.width / 2f
                        x.pivotY = 0f
                        x.scaleX = 0.94f
                        x.scaleY = 0.94f
                    }
                    x.visibility = VISIBLE
                }
                x.animate().alpha(1f).scaleX(1f).scaleY(1f)
                    .setStartDelay(90).setDuration(230)
                    .setInterpolator(DecelerateInterpolator(1.4f)).start()
            } else if (x.visibility == VISIBLE) {
                x.animate().alpha(0f)
                    .setStartDelay(0).setDuration(110)
                    .setInterpolator(DecelerateInterpolator())
                    .withEndAction { if (shown !== x) x.visibility = INVISIBLE }
                    .start()
            }
        }
    }

    // ------------------------------------------------------------ warna cover

    private fun setTintColors(c: Int) {
        shownTint = c
        tintBg.setColors(intArrayOf(c, darken(c, 0.42f)))
    }

    private fun updateTint() {
        val t = music.tint
        val want = state == S.PANEL && tab == 0 && t != 0
        if (t != 0 && t != shownTint) {
            tintAnim?.cancel()
            if (tintView.alpha < 0.05f) {
                setTintColors(t)
            } else {
                val a = ValueAnimator.ofObject(ArgbEvaluator(), shownTint, t)
                a.duration = 520
                a.addUpdateListener { setTintColors(it.animatedValue as Int) }
                a.start()
                tintAnim = a
            }
        }
        tintView.animate().cancel()
        tintView.animate().alpha(if (want) 1f else 0f).setStartDelay(0).setDuration(340)
            .setInterpolator(DecelerateInterpolator()).start()
    }

    // ------------------------------------------------------------ compact

    private fun updateCompact() {
        val pr = Nusa.prefs
        val minimal = pr.minimal
        val musicOn = media.hasSession && media.playing
        val art = media.art
        val showArt = musicOn && art != null && !minimal
        val showPet = !minimal && pr.pet && !showArt
        val timerOn = Nusa.pomo.running
        pet.visibility = if (showPet) VISIBLE else GONE
        miniArt.visibility = if (showArt) VISIBLE else GONE
        if (showArt && lastMiniArt !== art) {
            lastMiniArt = art
            miniArt.setImageBitmap(art)
        }
        cText.visibility = if (timerOn) VISIBLE else GONE
        if (timerOn) cText.text = fmtCountdown(Nusa.pomo.left())
        val showEq = musicOn && !minimal
        eq.visibility = if (showEq) VISIBLE else GONE
        eq.active = media.playing
        gap.visibility = if ((showArt || showPet) && (timerOn || showEq)) VISIBLE else GONE
    }

    private fun compactSize(): Pair<Int, Int> {
        compact.measure(MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED), MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED))
        val minimal = Nusa.prefs.minimal
        val minW = if (minimal) svc.dp(84) else svc.dp(126)
        val h = if (minimal) svc.dp(24) else svc.dp(34)
        return Pair(maxOf(minW, compact.measuredWidth + svc.dp(8)), h)
    }

    private fun setCompactHeight(h: Int) {
        val lp = compact.layoutParams
        if (lp.height != h) {
            lp.height = h
            compact.layoutParams = lp
        }
    }

    private fun fitCompact() {
        val (w, h) = compactSize()
        if (Math.abs(sw.target - w) > svc.dp(2) || sh.target != h.toFloat()) {
            setCompactHeight(h)
            morphTo(w.toFloat(), h.toFloat(), h / 2f)
        }
    }

    fun showCompact() {
        state = S.COMPACT
        ui.removeCallbacks(endAlert)
        updateCompact()
        val (w, h) = compactSize()
        setCompactHeight(h)
        morphTo(w.toFloat(), h.toFloat(), h / 2f)
        crossTo(compact)
        updateTint()
    }

    // ------------------------------------------------------------ alerts

    fun enqueue(a: Alert) {
        pet.wiggle()
        when (state) {
            S.PANEL -> return
            S.ALERT -> if (queue.size < 4) queue.add(a)
            S.COMPACT -> showAlert(a)
        }
    }

    private fun showAlert(a: Alert) {
        state = S.ALERT
        current = a
        aTitle.text = a.title
        aSub.text = a.sub
        if (a.icon != null) {
            aImg.visibility = VISIBLE
            aImg.setImageDrawable(a.icon)
            aGlyph.visibility = GONE
            aIconBox.background = null
        } else {
            aImg.visibility = GONE
            aGlyph.visibility = VISIBLE
            aGlyph.text = a.glyph
            aIconBox.background = rounded(a.color, svc.dpf(20))
        }
        val w = minOf((screenW() * 0.9f).toInt(), svc.dp(400))
        val lp = alertBox.layoutParams
        lp.width = w
        alertBox.layoutParams = lp
        morphTo(w.toFloat(), svc.dp(68).toFloat(), svc.dpf(34))
        crossTo(alertBox)
        updateTint()
        ui.removeCallbacks(endAlert)
        ui.postDelayed(endAlert, a.ms)
    }

    // ------------------------------------------------------------ panel

    fun showPanel(t: Int) {
        ui.removeCallbacks(endAlert)
        queue.clear()
        current = null
        val was = state == S.PANEL
        state = S.PANEL
        pw = minOf(screenW() - svc.dp(24), svc.dp(580))
        val lp = panelBox.layoutParams
        lp.width = pw
        panelBox.layoutParams = lp
        music.setWide(pw >= svc.dp(480))
        selectTab(t, was)
        morphTo(pw.toFloat(), panelH(t).toFloat(), svc.dpf(28))
        if (!was) crossTo(panelBox)
        updateTint()
    }

    private fun switchTab(t: Int) {
        if (t == tab || state != S.PANEL) return
        selectTab(t, true)
        morphTo(pw.toFloat(), panelH(t).toFloat(), svc.dpf(28))
        updateTint()
    }

    private fun selectTab(t: Int, fade: Boolean) {
        val changed = t != tab
        tab = t
        Nusa.prefs.lastTab = t
        for (i in panels.indices) {
            val p = panels[i]
            p.animate().cancel()
            if (i == t) {
                p.visibility = VISIBLE
                if (fade && changed) {
                    p.alpha = 0f
                    p.animate().alpha(1f).setStartDelay(70).setDuration(220)
                        .setInterpolator(DecelerateInterpolator()).start()
                } else {
                    p.alpha = 1f
                }
            } else {
                p.visibility = GONE
                p.alpha = 1f
            }
        }
        for (i in tabViews.indices) {
            val sel = i == t
            tabViews[i].setTextColor(if (sel) C.TEXT else C.SUB)
            tabViews[i].background = if (sel) rounded(0x26FFFFFF, svc.dpf(100)) else null
        }
        val bl = body.layoutParams
        bl.height = bodyH(t)
        body.layoutParams = bl
        val pl = panelBox.layoutParams
        pl.height = panelH(t)
        panelBox.layoutParams = pl
        (panels[t] as Refreshable).refresh()
        kick()
    }

    fun refreshData() {
        if (state == S.PANEL) (panels[tab] as Refreshable).refresh()
        kick()
    }

    fun applySettings() {
        if (state == S.COMPACT) showCompact()
    }

    // ------------------------------------------------------------ system hooks

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.action == MotionEvent.ACTION_OUTSIDE) {
            if (state == S.PANEL) showCompact()
            return true
        }
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = ev.rawX
                downY = ev.rawY
            }
            MotionEvent.ACTION_UP -> {
                // swipe ke atas di strip tab = tutup panel
                if (state == S.PANEL && downY - ev.rawY > svc.dp(48) && Math.abs(downX - ev.rawX) < svc.dp(60) &&
                    ev.y + (downY - ev.rawY) < tabsH() + svc.dp(24)
                ) {
                    val r = super.dispatchTouchEvent(ev)
                    showCompact()
                    return r
                }
            }
        }
        return super.dispatchTouchEvent(ev)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        post {
            when (state) {
                S.COMPACT -> showCompact()
                S.PANEL -> showPanel(tab)
                S.ALERT -> {
                }
            }
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        ui.post(uiTick)
        kick()
    }

    override fun onDetachedFromWindow() {
        ui.removeCallbacks(uiTick)
        ui.removeCallbacks(endAlert)
        choreo.removeFrameCallback(frameCb)
        ticking = false
        tintAnim?.cancel()
        super.onDetachedFromWindow()
    }
}
