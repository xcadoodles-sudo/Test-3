package com.nusa.notch

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.Context
import android.annotation.SuppressLint
import android.os.SystemClock
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextUtils
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.view.animation.PathInterpolator
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.random.Random

const val MATCH = -1
const val WRAP = -2

object C {
    val BLACK = 0xFF000000.toInt()
    val APP_BG = 0xFF0B0B10.toInt()
    val CARD = 0xFF1C1C21.toInt()
    val CARD2 = 0xFF2A2A31.toInt()
    val TEXT = 0xFFFFFFFF.toInt()
    val SUB = 0xFF9A9AA4.toInt()
    val ACCENT = 0xFF8B7BFF.toInt()
    val GREEN = 0xFF30D158.toInt()
    val RED = 0xFFFF453A.toInt()
    val BLUE = 0xFF0A84FF.toInt()
    val ORANGE = 0xFFFF9F0A.toInt()
    val CYAN = 0xFF40C8E0.toInt()
}

interface Refreshable {
    fun refresh()
}

fun Context.dp(v: Number): Int = (v.toFloat() * resources.displayMetrics.density + 0.5f).toInt()
fun Context.dpf(v: Number): Float = v.toFloat() * resources.displayMetrics.density

/** LayoutParams untuk LinearLayout. w/h dalam px (pakai dp() / MATCH / WRAP), margin dalam dp. */
fun Context.llp(w: Int, h: Int, weight: Float = 0f, ml: Int = 0, mt: Int = 0, mr: Int = 0, mb: Int = 0): LinearLayout.LayoutParams {
    val p = LinearLayout.LayoutParams(w, h, weight)
    p.setMargins(dp(ml), dp(mt), dp(mr), dp(mb))
    return p
}

fun rounded(color: Int, radiusPx: Float): GradientDrawable {
    val g = GradientDrawable()
    g.setColor(color)
    g.cornerRadius = radiusPx
    return g
}

fun Context.tv(text: String, sp: Float, color: Int = C.TEXT, bold: Boolean = false): TextView {
    val t = TextView(this)
    t.text = text
    t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
    t.setTextColor(color)
    if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
    t.includeFontPadding = false
    return t
}

fun Context.pill(text: String, bg: Int, fg: Int = C.TEXT, sp: Float = 13f, onClick: () -> Unit): TextView {
    val t = tv(text, sp, fg, true)
    t.gravity = Gravity.CENTER
    t.setPadding(dp(14), dp(8), dp(14), dp(8))
    t.background = rounded(bg, dpf(100))
    t.setOnClickListener { onClick() }
    return t
}

fun View.roundClip(radiusPx: Float) {
    outlineProvider = object : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) {
            outline.setRoundRect(0, 0, view.width, view.height, radiusPx)
        }
    }
    clipToOutline = true
}

fun fmtTime(ms: Long): String {
    val s = (if (ms < 0) 0L else ms) / 1000
    return "%d:%02d".format(s / 60, s % 60)
}

fun fmtCountdown(ms: Long): String {
    val s = ((if (ms < 0) 0L else ms) + 999) / 1000
    return "%02d:%02d".format(s / 60, s % 60)
}

/** Spring fisika sederhana (semi-implicit Euler, substep kecil) - stabil di 60/120/144 Hz. */
class Spring(var value: Float, private val stiffness: Float, private val dampingRatio: Float) {
    var target = value
    var velocity = 0f
    private val damping = 2f * dampingRatio * Math.sqrt(stiffness.toDouble()).toFloat()

    val atRest: Boolean
        get() = Math.abs(target - value) < 0.3f && Math.abs(velocity) < 6f

    fun snap(v: Float) {
        value = v
        target = v
        velocity = 0f
    }

    /** dt dalam detik. */
    fun step(dt: Float) {
        var left = if (dt < 0f) 0f else if (dt > 0.05f) 0.05f else dt
        while (left > 0f) {
            val h = if (left > 0.004f) 0.004f else left
            val acc = -stiffness * (value - target) - damping * velocity
            velocity += acc * h
            value += velocity * h
            left -= h
        }
    }
}

/** Efek "kenyal" saat disentuh: mengecil cepat, lalu membal balik. */
@SuppressLint("ClickableViewAccessibility")
fun View.pressScale(down: Float = 0.88f) {
    setOnTouchListener { v, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN ->
                v.animate().scaleX(down).scaleY(down).setStartDelay(0).setDuration(90)
                    .setInterpolator(DecelerateInterpolator()).start()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                v.animate().scaleX(1f).scaleY(1f).setStartDelay(0).setDuration(340)
                    .setInterpolator(OvershootInterpolator(2.6f)).start()
        }
        false
    }
}

/** Equalizer kecil (bar naik-turun), gerakannya dihaluskan (lerp), ~30 fps supaya hemat baterai. */
class EqView(c: Context) : View(c) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val cur = floatArrayOf(0.3f, 0.3f, 0.3f, 0.3f)
    private val tgt = floatArrayOf(0.4f, 0.8f, 0.5f, 0.7f)
    var active = true
    private var nextAt = 0L
    private val loop = object : Runnable {
        override fun run() {
            if (visibility != VISIBLE) {
                postDelayed(this, 250)
                return
            }
            val now = SystemClock.uptimeMillis()
            if (now >= nextAt) {
                nextAt = now + 170 + Random.nextLong(120L)
                for (i in tgt.indices) tgt[i] = if (active) 0.25f + Random.nextFloat() * 0.75f else 0.22f
            }
            var changed = false
            for (i in cur.indices) {
                val d = tgt[i] - cur[i]
                if (Math.abs(d) > 0.003f) {
                    cur[i] += d * 0.3f
                    changed = true
                }
            }
            if (changed) invalidate()
            postDelayed(this, 33)
        }
    }

    init {
        paint.color = C.ACCENT
    }

    fun setColor(c: Int) {
        paint.color = c
        invalidate()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        post(loop)
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(loop)
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        val n = cur.size
        val bw = width / (n * 2f - 1f)
        for (i in 0 until n) {
            val h = height * cur[i]
            val x = i * bw * 2f
            canvas.drawRoundRect(x, height - h, x + bw, height.toFloat(), bw / 2f, bw / 2f, paint)
        }
    }
}

/** Garis progress; bisa disentuh/digeser untuk seek kalau onSeek di-set. Menebal saat disentuh. */
class ProgressLine(private val c: Context) : View(c) {
    var frac: Float = 0f
        set(v) {
            field = v.coerceIn(0f, 1f)
            invalidate()
        }
    var fillColor: Int = C.TEXT
        set(v) {
            field = v
            invalidate()
        }
    var onSeek: ((Float) -> Unit)? = null
    var restDp = 6f
    var dragDp = 10f
    var dragging = false
        private set
    private var thick = -1f
    private var thickAnim: ValueAnimator? = null
    private val track = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        track.color = 0x33FFFFFF
    }

    private fun animThick(toDp: Float) {
        thickAnim?.cancel()
        if (thick < 0f) thick = restDp
        val a = ValueAnimator.ofFloat(thick, toDp)
        a.duration = 160
        a.addUpdateListener {
            thick = it.animatedValue as Float
            invalidate()
        }
        a.start()
        thickAnim = a
    }

    override fun onDraw(canvas: Canvas) {
        if (thick < 0f) thick = restDp
        val t = c.dpf(thick) / 2f
        val cy = height / 2f
        canvas.drawRoundRect(0f, cy - t, width.toFloat(), cy + t, t, t, track)
        fill.color = fillColor
        val fw = width * frac
        if (fw > 0.5f) canvas.drawRoundRect(0f, cy - t, Math.max(fw, t * 2f), cy + t, t, t, fill)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val cb = onSeek ?: return false
        if (width <= 0) return true
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                dragging = true
                parent?.requestDisallowInterceptTouchEvent(true)
                animThick(dragDp)
                frac = e.x / width
            }
            MotionEvent.ACTION_MOVE -> if (dragging) frac = e.x / width
            MotionEvent.ACTION_UP -> if (dragging) {
                dragging = false
                animThick(restDp)
                cb(frac)
            }
            MotionEvent.ACTION_CANCEL -> {
                dragging = false
                animThick(restDp)
            }
        }
        return true
    }
}

/** Tombol play/pause bulat putih; ikonnya morph halus (segitiga <-> dua batang). */
class PlayPauseView(private val c: Context) : View(c) {
    private val bgp = Paint(Paint.ANTI_ALIAS_FLAG)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private var t = 0f // 0 = play, 1 = pause
    private var anim: ValueAnimator? = null
    var playing: Boolean = false
        set(v) {
            if (field == v) return
            field = v
            go(if (v) 1f else 0f)
        }

    private val pl = floatArrayOf(0.24f, 0.12f, 0.54f, 0.31f, 0.54f, 0.69f, 0.24f, 0.88f)
    private val pr = floatArrayOf(0.54f, 0.31f, 0.86f, 0.50f, 0.86f, 0.50f, 0.54f, 0.69f)
    private val ql = floatArrayOf(0.20f, 0.12f, 0.40f, 0.12f, 0.40f, 0.88f, 0.20f, 0.88f)
    private val qr = floatArrayOf(0.60f, 0.12f, 0.80f, 0.12f, 0.80f, 0.88f, 0.60f, 0.88f)

    init {
        bgp.color = C.TEXT
        p.color = C.BLACK
        p.style = Paint.Style.FILL_AND_STROKE
        p.strokeJoin = Paint.Join.ROUND
    }

    private fun go(to: Float) {
        anim?.cancel()
        val a = ValueAnimator.ofFloat(t, to)
        a.duration = 240
        a.interpolator = DecelerateInterpolator(1.6f)
        a.addUpdateListener {
            t = it.animatedValue as Float
            invalidate()
        }
        a.start()
        anim = a
    }

    private fun quad(a: FloatArray, b: FloatArray, ox: Float, oy: Float, s: Float) {
        path.reset()
        for (i in 0 until 4) {
            val x = ox + (a[i * 2] + (b[i * 2] - a[i * 2]) * t) * s
            val y = oy + (a[i * 2 + 1] + (b[i * 2 + 1] - a[i * 2 + 1]) * t) * s
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
    }

    override fun onDraw(cv: Canvas) {
        val m = Math.min(width, height).toFloat()
        cv.drawCircle(width / 2f, height / 2f, m / 2f, bgp)
        val s = m * 0.40f
        val ox = (width - s) / 2f
        val oy = (height - s) / 2f
        p.strokeWidth = s * 0.10f
        quad(pl, ql, ox, oy, s)
        cv.drawPath(path, p)
        quad(pr, qr, ox, oy, s)
        cv.drawPath(path, p)
    }

    override fun onDetachedFromWindow() {
        anim?.cancel()
        super.onDetachedFromWindow()
    }
}

/** Tombol prev / next: segitiga + batang. */
class SkipView(c: Context, private val forward: Boolean) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    init {
        p.color = C.TEXT
        p.style = Paint.Style.FILL_AND_STROKE
        p.strokeJoin = Paint.Join.ROUND
    }

    private fun fx(x: Float): Float = if (forward) x else 1f - x

    override fun onDraw(cv: Canvas) {
        val m = Math.min(width, height).toFloat()
        val s = m * 0.46f
        val ox = (width - s) / 2f
        val oy = (height - s) / 2f
        p.strokeWidth = s * 0.10f
        path.reset()
        path.moveTo(ox + fx(0.08f) * s, oy + 0.14f * s)
        path.lineTo(ox + fx(0.72f) * s, oy + 0.50f * s)
        path.lineTo(ox + fx(0.08f) * s, oy + 0.86f * s)
        path.close()
        cv.drawPath(path, p)
        val a = ox + fx(0.78f) * s
        val b = ox + fx(0.92f) * s
        cv.drawRect(Math.min(a, b), oy + 0.14f * s, Math.max(a, b), oy + 0.86f * s, p)
    }
}

/**
 * Lirik tersinkron: baris aktif di tengah (putih, besar), baris lain redup & lebih kecil.
 * Pindah baris = scroll halus (ease-out), bukan lompat.
 */
class LyricsView(private val c: Context) : View(c) {
    private var lines: List<LrcLine>? = null
    private var msg = ""
    private var idx = -2
    private var focus = -1f
    private var anim: ValueAnimator? = null
    private val tp = TextPaint(Paint.ANTI_ALIAS_FLAG)
    private val mp = TextPaint(Paint.ANTI_ALIAS_FLAG)
    private val cache = HashMap<Int, StaticLayout>()
    private val gap = c.dpf(12)

    init {
        tp.textSize = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 16f, resources.displayMetrics)
        tp.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        tp.color = Color.WHITE
        mp.textSize = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 13f, resources.displayMetrics)
        mp.color = 0x80FFFFFF.toInt()
        mp.textAlign = Paint.Align.CENTER
    }

    fun setData(l: List<LrcLine>?, state: Int) {
        lines = l
        msg = when {
            l != null -> ""
            state == 1 -> "Loading lyrics..."
            state == 3 -> "Lyrics not available"
            else -> ""
        }
        cache.clear()
        anim?.cancel()
        idx = -2
        focus = -1f
        invalidate()
    }

    fun setIndex(i: Int) {
        if (i == idx) return
        idx = i
        anim?.cancel()
        val to = i.toFloat()
        if (width <= 0 || visibility != VISIBLE || Math.abs(to - focus) > 3f) {
            focus = to
            invalidate()
            return
        }
        val a = ValueAnimator.ofFloat(focus, to)
        a.duration = 460
        a.interpolator = PathInterpolator(0.22f, 1f, 0.36f, 1f)
        a.addUpdateListener {
            focus = it.animatedValue as Float
            invalidate()
        }
        a.start()
        anim = a
    }

    private fun textOf(j: Int): String? {
        val l = lines ?: return null
        if (j < -1 || j >= l.size) return null
        if (j == -1) return "\u266A"
        val t = l[j].text
        return if (t.isBlank()) "\u266A" else t
    }

    private fun layoutFor(j: Int): StaticLayout? {
        val hit = cache[j]
        if (hit != null) return hit
        val t = textOf(j) ?: return null
        if (width <= 0) return null
        val sl = StaticLayout.Builder.obtain(t, 0, t.length, tp, width)
            .setMaxLines(2)
            .setEllipsize(TextUtils.TruncateAt.END)
            .build()
        cache[j] = sl
        return sl
    }

    private fun hOf(j: Int): Float = layoutFor(j)?.height?.toFloat() ?: 0f

    private fun step(j: Int): Float = (hOf(j) + hOf(j + 1)) / 2f + gap

    private fun drawLine(cv: Canvas, j: Int, yc: Float) {
        val l = layoutFor(j) ?: return
        val wgt = (1f - Math.abs(j - focus)).coerceIn(0f, 1f)
        val sc = 0.86f + 0.14f * wgt
        var al = 0.36f + 0.64f * wgt
        val d = Math.min(yc, height - yc)
        al *= (d / (height * 0.3f)).coerceIn(0f, 1f)
        if (al <= 0.01f) return
        tp.alpha = (255f * al).toInt().coerceIn(0, 255)
        cv.save()
        cv.translate(0f, yc - l.height * sc / 2f)
        cv.scale(sc, sc, 0f, 0f)
        l.draw(cv)
        cv.restore()
    }

    override fun onDraw(cv: Canvas) {
        val ls = lines
        if (ls == null || ls.isEmpty()) {
            if (msg.isNotEmpty()) cv.drawText(msg, width / 2f, height / 2f + mp.textSize / 3f, mp)
            return
        }
        if (width <= 0) return
        val a = Math.floor(focus.toDouble()).toInt()
        val t = focus - a
        val yA = height / 2f - t * step(a)
        var y = yA
        var j = a
        while (j < ls.size) {
            if (y - hOf(j) / 2f > height) break
            drawLine(cv, j, y)
            y += step(j)
            j++
        }
        y = yA
        j = a - 1
        while (j >= -1) {
            y -= step(j)
            if (y + hOf(j) / 2f < 0f) break
            drawLine(cv, j, y)
            j--
        }
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        cache.clear()
    }

    override fun onDetachedFromWindow() {
        anim?.cancel()
        super.onDetachedFromWindow()
    }
}

/** Ambil warna dominan cover album (dibuat gelap) untuk latar panel musik. 0 = tidak ada. */
object Tint {
    fun of(b: Bitmap?): Int {
        if (b == null) return 0
        try {
            if (b.isRecycled || b.width <= 0 || b.height <= 0) return 0
            val n = 24
            val s = Bitmap.createScaledBitmap(b, n, n, true)
            val px = IntArray(n * n)
            s.getPixels(px, 0, n, 0, 0, n, n)
            val hsv = FloatArray(3)
            val wsum = FloatArray(12)
            val rs = FloatArray(12)
            val gs = FloatArray(12)
            val bs = FloatArray(12)
            var ar = 0f
            var ag = 0f
            var ab = 0f
            for (p in px) {
                val pr = (p shr 16) and 255
                val pg = (p shr 8) and 255
                val pb = p and 255
                ar += pr
                ag += pg
                ab += pb
                Color.RGBToHSV(pr, pg, pb, hsv)
                if (hsv[1] < 0.18f || hsv[2] < 0.15f) continue
                val k = (hsv[0] / 30f).toInt().coerceIn(0, 11)
                val w = hsv[1] * hsv[2]
                wsum[k] += w
                rs[k] += pr * w
                gs[k] += pg * w
                bs[k] += pb * w
            }
            var best = -1
            var bw = 0f
            for (k in 0 until 12) {
                if (wsum[k] > bw) {
                    bw = wsum[k]
                    best = k
                }
            }
            val fr: Float
            val fg: Float
            val fb: Float
            if (best >= 0 && bw > 1.5f) {
                fr = rs[best] / bw
                fg = gs[best] / bw
                fb = bs[best] / bw
            } else {
                val cnt = (n * n).toFloat()
                fr = ar / cnt
                fg = ag / cnt
                fb = ab / cnt
            }
            Color.RGBToHSV(fr.toInt(), fg.toInt(), fb.toInt(), hsv)
            hsv[1] = Math.min(1f, hsv[1] * 1.05f)
            hsv[2] = Math.min(hsv[2], 0.52f)
            return Color.HSVToColor(hsv)
        } catch (e: Exception) {
            return 0
        }
    }
}

/** Maskot kucing "Nusa" yang berkedip. */
class PetView(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var blink = 0f
    private val ui = Handler(Looper.getMainLooper())
    private val blinkRun = object : Runnable {
        override fun run() {
            val a = ValueAnimator.ofFloat(0f, 1f, 0f)
            a.duration = 190
            a.addUpdateListener {
                blink = it.animatedValue as Float
                invalidate()
            }
            a.start()
            ui.postDelayed(this, 2500L + Random.nextLong(3500L))
        }
    }

    fun wiggle() {
        ObjectAnimator.ofFloat(this, "rotation", 0f, -16f, 16f, -8f, 0f).setDuration(500).start()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        ui.postDelayed(blinkRun, 1500)
    }

    override fun onDetachedFromWindow() {
        ui.removeCallbacks(blinkRun)
        super.onDetachedFromWindow()
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val rect = RectF(w * 0.06f, h * 0.26f, w * 0.94f, h * 0.96f)
        p.shader = null
        p.style = Paint.Style.FILL
        p.color = 0xFF2B2B33.toInt()
        cv.drawRoundRect(rect, w * 0.34f, w * 0.34f, p)
        val e1 = Path()
        e1.moveTo(w * 0.08f, h * 0.52f)
        e1.lineTo(w * 0.14f, h * 0.06f)
        e1.lineTo(w * 0.44f, h * 0.30f)
        e1.close()
        cv.drawPath(e1, p)
        val e2 = Path()
        e2.moveTo(w * 0.92f, h * 0.52f)
        e2.lineTo(w * 0.86f, h * 0.06f)
        e2.lineTo(w * 0.56f, h * 0.30f)
        e2.close()
        cv.drawPath(e2, p)
        p.shader = LinearGradient(0f, h * 0.60f, 0f, h, 0x007C6CFF, 0xDD4A8CFF.toInt(), Shader.TileMode.CLAMP)
        cv.drawRoundRect(rect, w * 0.34f, w * 0.34f, p)
        p.shader = null
        p.color = 0xFFEAF1FF.toInt()
        val ry = h * 0.11f * (1f - 0.9f * blink)
        cv.drawOval(RectF(w * 0.23f, h * 0.60f - ry, w * 0.41f, h * 0.60f + ry), p)
        cv.drawOval(RectF(w * 0.59f, h * 0.60f - ry, w * 0.77f, h * 0.60f + ry), p)
    }
}
