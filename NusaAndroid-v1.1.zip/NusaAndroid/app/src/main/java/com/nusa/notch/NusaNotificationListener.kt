package com.nusa.notch

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Dua fungsi: (1) syarat agar MediaSessionManager boleh membaca sesi musik,
 * (2) meneruskan notifikasi app lain ke notch.
 */
class NusaNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        if (!NotchService.isRunning() || !Nusa.prefs.notifAlerts) return
        if (sbn.packageName == packageName) return
        if (sbn.isOngoing) return
        val n = sbn.notification ?: return
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val cat = n.category
        if (cat == Notification.CATEGORY_TRANSPORT || cat == Notification.CATEGORY_PROGRESS || cat == Notification.CATEGORY_SERVICE) return
        val ex = n.extras
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val text = (ex.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: ex.getCharSequence(Notification.EXTRA_TEXT))?.toString() ?: ""
        if (title.isBlank() && text.isBlank()) return
        val pm = packageManager
        val label = try {
            pm.getApplicationLabel(pm.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (e: Exception) {
            sbn.packageName
        }
        val icon = try {
            pm.getApplicationIcon(sbn.packageName)
        } catch (e: Exception) {
            null
        }
        val pi = n.contentIntent
        Bus.alert(
            Alert(
                if (title.isBlank()) label else title,
                if (text.isBlank()) label else text,
                "🔔", C.BLUE, icon, 4000L,
                onClick = {
                    try {
                        pi?.send()
                    } catch (e: Exception) {
                    }
                }
            )
        )
    }
}
