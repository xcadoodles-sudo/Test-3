package com.nusa.notch

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.TimePicker
import java.util.Calendar

/** Dialog kecil untuk Add Task / Edit Task (dipanggil dari panel Todo di notch). */
class TaskEditActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        val id = intent.getLongExtra("id", -1L)
        val existing = Nusa.todo.tasks.firstOrNull { it.id == id }

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(22), dp(18), dp(22), dp(14))
        root.addView(tv(if (existing == null) "Add Task" else "Edit Task", 20f, C.TEXT, true), llp(WRAP, WRAP, 0f, 0, 0, 0, 12))

        val et = EditText(this)
        et.hint = "Task title"
        et.setSingleLine(true)
        et.setText(existing?.title ?: "")
        et.setSelection(et.text.length)
        root.addView(et, llp(dp(320), WRAP))

        val cb = CheckBox(this)
        cb.text = "Remind me at"
        cb.isChecked = existing != null && existing.remindAt > 0
        root.addView(cb, llp(WRAP, WRAP, 0f, 0, 10, 0, 0))

        val tp = TimePicker(this)
        tp.setIs24HourView(true)
        val cal = Calendar.getInstance()
        if (existing != null && existing.remindAt > 0) cal.timeInMillis = existing.remindAt
        tp.hour = cal.get(Calendar.HOUR_OF_DAY)
        tp.minute = cal.get(Calendar.MINUTE)
        tp.visibility = if (cb.isChecked) android.view.View.VISIBLE else android.view.View.GONE
        cb.setOnCheckedChangeListener { _, v -> tp.visibility = if (v) android.view.View.VISIBLE else android.view.View.GONE }
        root.addView(tp)

        val btns = LinearLayout(this)
        btns.gravity = Gravity.END
        if (existing != null) {
            btns.addView(pill("Delete", C.CARD2, C.RED, 13f) {
                Nusa.todo.remove(existing.id)
                Bus.changed()
                finish()
            }, llp(WRAP, WRAP, 0f, 0, 0, 8, 0))
        }
        btns.addView(pill("Cancel", C.CARD2, C.TEXT, 13f) { finish() }, llp(WRAP, WRAP, 0f, 0, 0, 8, 0))
        btns.addView(pill("Save", C.ACCENT, C.TEXT, 13f) {
            val title = et.text.toString().trim()
            if (title.isEmpty()) {
                et.error = "Required"
            } else {
                var at = 0L
                if (cb.isChecked) {
                    val c = Calendar.getInstance()
                    c.set(Calendar.HOUR_OF_DAY, tp.hour)
                    c.set(Calendar.MINUTE, tp.minute)
                    c.set(Calendar.SECOND, 0)
                    c.set(Calendar.MILLISECOND, 0)
                    if (c.timeInMillis <= System.currentTimeMillis()) c.add(Calendar.DAY_OF_YEAR, 1)
                    at = c.timeInMillis
                }
                if (existing != null) Nusa.todo.update(existing.id, title, at) else Nusa.todo.add(title, at)
                Bus.changed()
                finish()
            }
        })
        root.addView(btns, llp(MATCH, WRAP, 0f, 0, 12, 0, 0))
        setContentView(root)
    }
}
