package com.nusa.notch

import android.app.Application
import android.content.Context
import android.content.SharedPreferences
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Calendar
import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty

/** Satu "notifikasi" yang tampil di notch. tab >= 0 -> ketuk membuka tab panel itu. */
data class Alert(
    val title: String,
    val sub: String,
    val glyph: String,
    val color: Int,
    val icon: Drawable? = null,
    val ms: Long = 3500L,
    val tab: Int = -1,
    val onClick: (() -> Unit)? = null
)

object Bus {
    private val main = Handler(Looper.getMainLooper())
    @Volatile var sink: ((Alert) -> Unit)? = null
    @Volatile var dataChanged: (() -> Unit)? = null
    fun alert(a: Alert) {
        main.post { sink?.invoke(a) }
    }
    fun changed() {
        main.post { dataChanged?.invoke() }
    }
}

class NusaApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Nusa.init(this)
    }
}

object Nusa {
    lateinit var prefs: Prefs
    lateinit var todo: TodoStore
    lateinit var pomo: Pomodoro
    lateinit var water: Water
    lateinit var shelf: ShelfStore
    fun init(app: Application) {
        prefs = Prefs(app)
        todo = TodoStore(prefs)
        pomo = Pomodoro(prefs)
        water = Water(prefs)
        shelf = ShelfStore(app)
    }
}

class BoolPref(private val sp: SharedPreferences, private val key: String, private val def: Boolean) : ReadWriteProperty<Any?, Boolean> {
    override fun getValue(thisRef: Any?, property: KProperty<*>): Boolean = sp.getBoolean(key, def)
    override fun setValue(thisRef: Any?, property: KProperty<*>, value: Boolean) {
        sp.edit().putBoolean(key, value).apply()
    }
}

class IntPref(private val sp: SharedPreferences, private val key: String, private val def: Int) : ReadWriteProperty<Any?, Int> {
    override fun getValue(thisRef: Any?, property: KProperty<*>): Int = sp.getInt(key, def)
    override fun setValue(thisRef: Any?, property: KProperty<*>, value: Int) {
        sp.edit().putInt(key, value).apply()
    }
}

class LongPref(private val sp: SharedPreferences, private val key: String, private val def: Long) : ReadWriteProperty<Any?, Long> {
    override fun getValue(thisRef: Any?, property: KProperty<*>): Long = sp.getLong(key, def)
    override fun setValue(thisRef: Any?, property: KProperty<*>, value: Long) {
        sp.edit().putLong(key, value).apply()
    }
}

class Prefs(ctx: Context) {
    val sp: SharedPreferences = ctx.getSharedPreferences("nusa", Context.MODE_PRIVATE)
    var pet by BoolPref(sp, "pet", true)
    var minimal by BoolPref(sp, "minimal", false)
    var notifAlerts by BoolPref(sp, "notifAlerts", true)
    var startOnBoot by BoolPref(sp, "boot", false)
    var topOffset by IntPref(sp, "topOffset", 6)
    var lastTab by IntPref(sp, "lastTab", 0)
}

fun dayKey(): Int {
    val c = Calendar.getInstance()
    return c.get(Calendar.YEAR) * 10000 + (c.get(Calendar.MONTH) + 1) * 100 + c.get(Calendar.DAY_OF_MONTH)
}

fun nowMinutes(): Int {
    val c = Calendar.getInstance()
    return c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
}

// ---------------------------------------------------------------- Todo

data class Task(val id: Long, var title: String, var done: Boolean = false, var remindAt: Long = 0L, var notified: Boolean = false)

class TodoStore(private val p: Prefs) {
    val tasks = mutableListOf<Task>()
    private var doneDay by IntPref(p.sp, "doneDay", 0)
    private var doneCount by IntPref(p.sp, "doneCount", 0)

    init {
        load()
    }

    private fun load() {
        tasks.clear()
        val s = p.sp.getString("todo", "[]") ?: "[]"
        try {
            val a = JSONArray(s)
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                tasks.add(Task(o.getLong("id"), o.getString("title"), o.optBoolean("done"), o.optLong("at"), o.optBoolean("notified")))
            }
        } catch (e: Exception) {
        }
    }

    fun save() {
        val a = JSONArray()
        for (t in tasks) {
            a.put(JSONObject().put("id", t.id).put("title", t.title).put("done", t.done).put("at", t.remindAt).put("notified", t.notified))
        }
        p.sp.edit().putString("todo", a.toString()).apply()
    }

    fun add(title: String, remindAt: Long) {
        tasks.add(0, Task(System.currentTimeMillis(), title, false, remindAt, false))
        save()
    }

    fun update(id: Long, title: String, remindAt: Long) {
        val t = tasks.firstOrNull { it.id == id } ?: return
        t.title = title
        if (t.remindAt != remindAt) t.notified = false
        t.remindAt = remindAt
        save()
    }

    fun remove(id: Long) {
        tasks.removeAll { it.id == id }
        save()
    }

    fun toggle(id: Long) {
        val t = tasks.firstOrNull { it.id == id } ?: return
        ensureDay()
        t.done = !t.done
        doneCount = if (t.done) doneCount + 1 else maxOf(0, doneCount - 1)
        save()
    }

    private fun ensureDay() {
        val d = dayKey()
        if (doneDay != d) {
            doneDay = d
            doneCount = 0
        }
    }

    fun doneToday(): Int {
        ensureDay()
        return doneCount
    }

    fun due(now: Long): List<Task> = tasks.filter { !it.done && !it.notified && it.remindAt in 1..now }
}

// ---------------------------------------------------------------- Pomodoro

class Pomodoro(private val p: Prefs) {
    enum class Mode(val label: String, val min: Int) {
        FOCUS("Focus", 25), SHORT("Short Break", 5), LONG("Long Break", 15)
    }

    var mode: Mode = Mode.values()[p.sp.getInt("pomoMode", 0).coerceIn(0, 2)]
    var running: Boolean = p.sp.getBoolean("pomoRun", false)
    private var endAt: Long = p.sp.getLong("pomoEnd", 0L)
    private var remain: Long = p.sp.getLong("pomoRemain", 25 * 60_000L)
    var sessions: Int = p.sp.getInt("pomoSessions", 0)

    private fun save() {
        p.sp.edit()
            .putInt("pomoMode", mode.ordinal).putBoolean("pomoRun", running)
            .putLong("pomoEnd", endAt).putLong("pomoRemain", remain)
            .putInt("pomoSessions", sessions).apply()
    }

    fun left(): Long = if (running) maxOf(0L, endAt - System.currentTimeMillis()) else remain

    fun toggle() {
        if (running) {
            remain = left()
            running = false
        } else {
            if (remain <= 0L) remain = mode.min * 60_000L
            endAt = System.currentTimeMillis() + remain
            running = true
        }
        save()
    }

    fun reset() {
        running = false
        remain = mode.min * 60_000L
        save()
    }

    fun select(m: Mode) {
        mode = m
        running = false
        remain = m.min * 60_000L
        save()
    }

    /** Dipanggil tiap detik. Mengembalikan Alert kalau satu fase baru saja selesai. */
    fun tick(): Alert? {
        if (!running || left() > 0L) return null
        running = false
        val a: Alert
        if (mode == Mode.FOCUS) {
            sessions++
            if (sessions % 4 == 0) {
                mode = Mode.LONG
                a = Alert("Long Break!", "15 min, you earned it", "☕", C.GREEN, tab = 1, ms = 5000)
            } else {
                mode = Mode.SHORT
                a = Alert("Break Time!", "5 minute short break", "☕", C.GREEN, tab = 1, ms = 5000)
            }
        } else {
            mode = Mode.FOCUS
            a = Alert("Focus Time!", "Back to work, 25 min", "⏱", C.ORANGE, tab = 1, ms = 5000)
        }
        remain = mode.min * 60_000L
        save()
        return a
    }
}

// ---------------------------------------------------------------- Water

class Water(private val p: Prefs) {
    private val sp = p.sp
    val bottleOptions = intArrayOf(1500, 2000, 2500, 3000)

    val isOn: Boolean get() = sp.getBoolean("wOn", false)
    var bottle by IntPref(sp, "wBottle", 2000)
    var goal by IntPref(sp, "wGoal", 2500)
    var startH by IntPref(sp, "wStart", 8)
    var endH by IntPref(sp, "wEnd", 22)
    var taken by IntPref(sp, "wTaken", 0)
    private var inRaw by IntPref(sp, "wIn", -1)
    var fired by IntPref(sp, "wFired", 0)
    private var wDay by IntPref(sp, "wDay", 0)
    private var snoozeUntil by LongPref(sp, "wSnooze", 0L)

    val inBottle: Int get() = if (inRaw < 0) bottle else inRaw

    fun setOn(v: Boolean) {
        sp.edit().putBoolean("wOn", v).apply()
        if (v) resync()
    }

    fun chooseBottle(v: Int) {
        bottle = v
        inRaw = v
    }

    fun setHours(s: Int, e: Int) {
        startH = s.coerceIn(0, 22)
        endH = e.coerceIn(startH + 1, 23)
        resync()
    }

    fun reminders(): Int = maxOf(1, endH - startH)

    fun mlEach(): Int = (((goal / reminders()) + 25) / 50 * 50).coerceAtLeast(50)

    fun refillsPerDay(): Int = (goal + bottle - 1) / bottle

    private fun expectedIdx(now: Int): Int = (((now - startH * 60) / 60) + 1).coerceIn(0, reminders())

    fun ensureToday() {
        val d = dayKey()
        if (wDay != d) {
            wDay = d
            taken = 0
            fired = 0
            inRaw = bottle
            snoozeUntil = 0L
        }
    }

    fun resync() {
        ensureToday()
        fired = expectedIdx(nowMinutes())
    }

    fun drink() {
        ensureToday()
        taken += mlEach()
        inRaw = maxOf(0, inBottle - mlEach())
    }

    fun refill() {
        inRaw = bottle
    }

    fun snooze() {
        snoozeUntil = System.currentTimeMillis() + 10 * 60_000L
        if (fired > 0) fired = fired - 1
    }

    fun reset() {
        taken = 0
        fired = 0
        inRaw = bottle
        snoozeUntil = 0L
        resync()
    }

    fun nextText(): String {
        if (!isOn) return "Reminders off"
        if (fired >= reminders()) return "All reminders done today"
        val m = startH * 60 + fired * 60
        return "Next %02d:%02d".format(m / 60, m % 60)
    }

    fun tick(): Alert? {
        ensureToday()
        if (!isOn) return null
        val now = nowMinutes()
        if (now < startH * 60 || now > endH * 60) return null
        if (System.currentTimeMillis() < snoozeUntil) return null
        val idx = expectedIdx(now)
        if (idx <= fired) return null
        fired = idx
        if (taken >= goal) return null
        return if (inBottle <= 0) {
            Alert("Time to Refill", "Your bottle is probably empty", "💧", C.CYAN, tab = 3, ms = 5000)
        } else {
            Alert("Time to Drink", "Stay hydrated! ${mlEach()} ml", "💧", C.CYAN, tab = 3, ms = 5000)
        }
    }
}

// ---------------------------------------------------------------- Shelf

class ShelfStore(private val ctx: Context) {
    val dir: File
        get() {
            val d = File(ctx.filesDir, "NusaShelf")
            d.mkdirs()
            return d
        }

    fun items(): List<File> = (dir.listFiles()?.filter { it.isFile } ?: emptyList()).sortedByDescending { it.lastModified() }

    fun isLink(f: File): Boolean = f.extension.equals("url", true)

    fun linkTarget(f: File): String? {
        return try {
            f.readLines().firstOrNull { it.startsWith("URL=") }?.substring(4)?.trim()
        } catch (e: Exception) {
            null
        }
    }

    fun uriFor(f: File): Uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)

    private fun uniqueFile(name: String): File {
        var f = File(dir, name)
        if (!f.exists()) return f
        val base = if (name.contains('.')) name.substringBeforeLast('.') else name
        val ext = if (name.contains('.')) "." + name.substringAfterLast('.') else ""
        var i = 1
        while (true) {
            f = File(dir, "$base ($i)$ext")
            if (!f.exists()) return f
            i++
        }
    }

    private fun clean(n: String): String {
        val s = n.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim()
        return if (s.isEmpty()) "file" else s
    }

    fun addUri(uri: Uri): Boolean {
        return try {
            var name: String? = null
            try {
                ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                    if (it.moveToFirst()) name = it.getString(0)
                }
            } catch (e: Exception) {
            }
            val n = clean(name ?: uri.lastPathSegment ?: "file")
            val out = uniqueFile(n)
            val input = ctx.contentResolver.openInputStream(uri) ?: return false
            input.use { i -> out.outputStream().use { o -> i.copyTo(o) } }
            true
        } catch (e: Exception) {
            false
        }
    }

    fun addLink(url: String) {
        val host = try {
            Uri.parse(url).host ?: "link"
        } catch (e: Exception) {
            "link"
        }
        val f = uniqueFile(clean(host) + ".url")
        f.writeText("[InternetShortcut]\nURL=$url\n")
    }

    fun remove(f: File) {
        f.delete()
    }

    fun clear() {
        items().forEach { it.delete() }
    }
}
