package com.nusa.notch

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Paint
import android.net.Uri
import android.provider.Settings
import android.text.TextUtils
import android.view.DragEvent
import android.view.Gravity
import android.view.View
import android.webkit.MimeTypeMap
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File

// ------------------------------------------------------------------ MUSIC

/**
 * Kartu musik ala Nusa Windows: cover + judul, progress (01:05 ... -01:38), kontrol,
 * dan lirik tersinkron di kanan. Warna latar NotchView mengikuti warna cover ([tint]).
 */
class MusicPanel(private val c: Context, private val m: MediaWatcher) : FrameLayout(c), Refreshable {
    var onTint: ((Int) -> Unit)? = null
    var tint = 0
        private set

    private val dim = 0xB3FFFFFF.toInt()
    private val art = ImageView(c)
    private val tTitle = c.tv("", 17f, C.TEXT, true)
    private val tArtist = c.tv("", 13f, dim)
    private val bar = ProgressLine(c)
    private val tCur = c.tv("0:00", 11f, dim)
    private val tRem = c.tv("-0:00", 11f, dim)
    private val bPlay = PlayPauseView(c)
    private val lyrics = LyricsView(c)
    private val content = LinearLayout(c)
    private val empty = LinearLayout(c)
    private val emptyTxt = c.tv("", 15f, C.SUB)
    private val emptyBtn: TextView
    private var lastArt: Bitmap? = null
    private var lastTitle = ""
    private var lastArtist = ""
    private var lastSec = -1L
    private var lastLyrics: List<LrcLine>? = null
    private var lastLyState = -1

    fun setWide(on: Boolean) {
        lyrics.visibility = if (on) VISIBLE else GONE
    }

    init {
        content.orientation = LinearLayout.HORIZONTAL
        content.gravity = Gravity.CENTER_VERTICAL

        val left = LinearLayout(c)
        left.orientation = LinearLayout.VERTICAL

        // --- kepala: cover + judul/artis
        val head = LinearLayout(c)
        head.gravity = Gravity.CENTER_VERTICAL
        art.scaleType = ImageView.ScaleType.CENTER_CROP
        art.background = rounded(0x22FFFFFF, c.dpf(14))
        art.roundClip(c.dpf(14))
        head.addView(art, c.llp(c.dp(60), c.dp(60)))
        val names = LinearLayout(c)
        names.orientation = LinearLayout.VERTICAL
        tTitle.maxLines = 1
        tTitle.ellipsize = TextUtils.TruncateAt.END
        tArtist.maxLines = 1
        tArtist.ellipsize = TextUtils.TruncateAt.END
        names.addView(tTitle)
        names.addView(tArtist, c.llp(WRAP, WRAP, 0f, 0, 3, 0, 0))
        head.addView(names, c.llp(0, WRAP, 1f, 12, 0, 0, 0))
        left.addView(head, c.llp(MATCH, WRAP))

        // --- progress: 01:05 ━━━●━━ -01:38
        val prog = LinearLayout(c)
        prog.gravity = Gravity.CENTER_VERTICAL
        tCur.minWidth = c.dp(34)
        tRem.minWidth = c.dp(40)
        tRem.gravity = Gravity.END
        bar.restDp = 4f
        bar.dragDp = 8f
        bar.onSeek = { f -> m.seekFrac(f) }
        prog.addView(tCur)
        prog.addView(bar, c.llp(0, c.dp(22), 1f, 8, 0, 8, 0))
        prog.addView(tRem)
        left.addView(prog, c.llp(MATCH, WRAP, 0f, 0, 10, 0, 0))

        // --- kontrol
        val row = LinearLayout(c)
        row.gravity = Gravity.CENTER
        val prev = SkipView(c, false)
        prev.pressScale(0.82f)
        prev.setOnClickListener { m.prev() }
        row.addView(prev, c.llp(c.dp(46), c.dp(46)))
        bPlay.pressScale(0.9f)
        bPlay.setOnClickListener { m.toggle() }
        row.addView(bPlay, c.llp(c.dp(50), c.dp(50), 0f, 20, 0, 20, 0))
        val next = SkipView(c, true)
        next.pressScale(0.82f)
        next.setOnClickListener { m.next() }
        row.addView(next, c.llp(c.dp(46), c.dp(46)))
        left.addView(row, c.llp(MATCH, 0, 1f, 0, 2, 0, 0))

        content.addView(left, c.llp(0, MATCH, 1.15f))
        content.addView(lyrics, c.llp(0, MATCH, 1f, 18, 0, 0, 0))
        addView(content, LayoutParams(MATCH, MATCH))

        empty.orientation = LinearLayout.VERTICAL
        empty.gravity = Gravity.CENTER
        emptyTxt.gravity = Gravity.CENTER
        empty.addView(emptyTxt)
        emptyBtn = c.pill("Open settings", C.ACCENT) {
            val i = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try {
                c.startActivity(i)
            } catch (e: Exception) {
            }
        }
        empty.addView(emptyBtn, c.llp(WRAP, WRAP, 0f, 0, 12, 0, 0))
        addView(empty, LayoutParams(MATCH, MATCH))
    }

    /** Update metadata (dipanggil saat data berubah + tiap 500 ms oleh NotchView). */
    override fun refresh() {
        m.ensure()
        val has = m.hasSession && (m.title.isNotBlank() || m.artist.isNotBlank())
        content.visibility = if (has) VISIBLE else GONE
        empty.visibility = if (has) GONE else VISIBLE
        if (!has) {
            emptyTxt.text = if (!m.granted) "Allow notification access\nto see and control your music" else "Nothing playing"
            emptyBtn.visibility = if (!m.granted) VISIBLE else GONE
            if (tint != 0) {
                tint = 0
                onTint?.invoke(0)
            }
            return
        }
        if (lastTitle != m.title) {
            lastTitle = m.title
            tTitle.text = m.title
        }
        if (lastArtist != m.artist) {
            lastArtist = m.artist
            tArtist.text = m.artist
        }
        if (lastArt !== m.art) {
            lastArt = m.art
            art.setImageBitmap(m.art)
            tint = Tint.of(m.art)
            onTint?.invoke(tint)
        }
        bPlay.playing = m.playing
        if (lastLyrics !== m.lyrics || lastLyState != m.lyricsState) {
            lastLyrics = m.lyrics
            lastLyState = m.lyricsState
            lyrics.setData(m.lyrics, m.lyricsState)
        }
        frame()
    }

    /**
     * Dipanggil NotchView tiap frame layar selagi panel musik terbuka: progress bar & lirik
     * bergerak mulus. Return true kalau masih perlu frame berikutnya (lagi play / disentuh).
     */
    fun frame(): Boolean {
        if (content.visibility != VISIBLE) return false
        val pos = m.position()
        if (!bar.dragging) bar.frac = if (m.duration > 0) pos.toFloat() / m.duration else 0f
        val sec = pos / 1000
        if (sec != lastSec) {
            lastSec = sec
            tCur.text = fmtTime(pos)
            tRem.text = if (m.duration > 0) "-" + fmtTime(m.duration - pos) else "--:--"
        }
        lyrics.setIndex(m.lyricIndex())
        return m.playing || bar.dragging
    }
}

// ------------------------------------------------------------------ TIMER

class TimerPanel(private val c: Context) : FrameLayout(c), Refreshable {
    private val chips = ArrayList<TextView>()
    private val time = c.tv("25:00", 56f, C.TEXT, true)
    private val sess = c.tv("", 13f, C.SUB)
    private val bStart: TextView

    init {
        val col = LinearLayout(c)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER
        val chipRow = LinearLayout(c)
        chipRow.gravity = Gravity.CENTER
        for (mode in Pomodoro.Mode.values()) {
            val t = c.tv(mode.label, 13f, C.TEXT, true)
            t.setPadding(c.dp(14), c.dp(7), c.dp(14), c.dp(7))
            t.setOnClickListener {
                Nusa.pomo.select(mode)
                refresh()
            }
            chips.add(t)
            chipRow.addView(t, c.llp(WRAP, WRAP, 0f, 4, 0, 4, 0))
        }
        col.addView(chipRow)
        time.gravity = Gravity.CENTER
        col.addView(time, c.llp(WRAP, WRAP, 0f, 0, 8, 0, 4))
        col.addView(sess)
        val btns = LinearLayout(c)
        btns.gravity = Gravity.CENTER
        bStart = c.pill("Start", C.ACCENT) {
            Nusa.pomo.toggle()
            refresh()
        }
        val bReset = c.pill("Reset", C.CARD2) {
            Nusa.pomo.reset()
            refresh()
        }
        btns.addView(bStart, c.llp(c.dp(110), WRAP, 0f, 0, 0, 8, 0))
        btns.addView(bReset, c.llp(c.dp(90), WRAP))
        col.addView(btns, c.llp(WRAP, WRAP, 0f, 0, 14, 0, 0))
        addView(col, LayoutParams(MATCH, MATCH))
    }

    override fun refresh() {
        val p = Nusa.pomo
        time.text = fmtCountdown(p.left())
        bStart.text = if (p.running) "Pause" else "Start"
        sess.text = "Pomodoro · ${p.sessions} done"
        val modes = Pomodoro.Mode.values()
        for (i in chips.indices) {
            val sel = modes[i] == p.mode
            chips[i].background = rounded(if (sel) C.ACCENT else C.CARD2, c.dpf(100))
            chips[i].setTextColor(if (sel) C.TEXT else C.SUB)
        }
    }
}

// ------------------------------------------------------------------ TODO

class TodoPanel(private val c: Context) : FrameLayout(c), Refreshable {
    private val doneTxt = c.tv("", 12f, C.SUB)
    private val list = LinearLayout(c)
    private var sig = ""

    private fun openEdit(id: Long) {
        val i = Intent(c, TaskEditActivity::class.java)
        i.putExtra("id", id)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        c.startActivity(i)
    }

    init {
        val col = LinearLayout(c)
        col.orientation = LinearLayout.VERTICAL
        val head = LinearLayout(c)
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(c.tv("TodoList", 17f, C.TEXT, true))
        head.addView(View(c), c.llp(0, 1, 1f))
        doneTxt.setPadding(0, 0, c.dp(10), 0)
        head.addView(doneTxt)
        head.addView(c.pill("+ Add Task", C.ACCENT, C.TEXT, 12f) { openEdit(-1L) })
        col.addView(head, c.llp(MATCH, WRAP, 0f, 0, 0, 0, 8))
        val sv = ScrollView(c)
        list.orientation = LinearLayout.VERTICAL
        sv.addView(list, LayoutParams(MATCH, WRAP))
        col.addView(sv, c.llp(MATCH, 0, 1f))
        addView(col, LayoutParams(MATCH, MATCH))
    }

    override fun refresh() {
        val ts = Nusa.todo.tasks
        val s = ts.joinToString("|") { "${it.id}:${it.title}:${it.done}:${it.remindAt}" } + "#" + Nusa.todo.doneToday()
        if (s == sig) return
        sig = s
        doneTxt.text = "Task Done Today: ${Nusa.todo.doneToday()}"
        list.removeAllViews()
        if (ts.isEmpty()) {
            val e = c.tv("No tasks.", 14f, C.SUB)
            e.setPadding(0, c.dp(20), 0, 0)
            list.addView(e)
            return
        }
        for (t in ts) {
            val row = LinearLayout(c)
            row.gravity = Gravity.CENTER_VERTICAL
            row.background = rounded(C.CARD, c.dpf(14))
            row.setPadding(c.dp(12), c.dp(10), c.dp(8), c.dp(10))
            val chk = c.tv(if (t.done) "●" else "○", 18f, if (t.done) C.GREEN else C.SUB, true)
            chk.setPadding(0, 0, c.dp(10), 0)
            row.addView(chk)
            val title = c.tv(t.title, 15f, if (t.done) C.SUB else C.TEXT)
            title.maxLines = 1
            title.ellipsize = TextUtils.TruncateAt.END
            if (t.done) title.paintFlags = title.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
            row.addView(title, c.llp(0, WRAP, 1f))
            if (t.remindAt > 0) {
                val cal = java.util.Calendar.getInstance()
                cal.timeInMillis = t.remindAt
                val tm = c.tv("%02d:%02d".format(cal.get(java.util.Calendar.HOUR_OF_DAY), cal.get(java.util.Calendar.MINUTE)), 12f, C.CYAN)
                row.addView(tm, c.llp(WRAP, WRAP, 0f, 8, 0, 4, 0))
            }
            val edit = c.tv("✎", 17f, C.SUB)
            edit.setPadding(c.dp(10), c.dp(4), c.dp(10), c.dp(4))
            edit.setOnClickListener { openEdit(t.id) }
            row.addView(edit)
            row.setOnClickListener {
                Nusa.todo.toggle(t.id)
                refresh()
            }
            row.setOnLongClickListener {
                openEdit(t.id)
                true
            }
            list.addView(row, c.llp(MATCH, WRAP, 0f, 0, 0, 0, 6))
        }
    }
}

// ------------------------------------------------------------------ WATER

class WaterPanel(private val c: Context) : FrameLayout(c), Refreshable {
    private val main = LinearLayout(c)
    private val sett = LinearLayout(c)
    private val tToday = c.tv("0 ml", 32f, C.TEXT, true)
    private val tGoal = c.tv("", 13f, C.SUB)
    private val tNext = c.tv("", 14f, C.CYAN, true)
    private val tSum = c.tv("", 12f, C.SUB)
    private val tBottle = c.tv("", 12f, C.SUB)
    private val prog = ProgressLine(c)
    private val bOn: TextView
    private val bottleChips = ArrayList<TextView>()
    private val tGoalSet = c.tv("", 15f, C.TEXT, true)
    private val tStart = c.tv("", 15f, C.TEXT, true)
    private val tEnd = c.tv("", 15f, C.TEXT, true)
    private val bReset: TextView
    private var confirm = false

    private fun stepper(label: TextView, minus: () -> Unit, plus: () -> Unit): LinearLayout {
        val r = LinearLayout(c)
        r.gravity = Gravity.CENTER_VERTICAL
        val m = c.pill("−", C.CARD2, C.TEXT, 16f) {
            minus()
            refresh()
        }
        val p = c.pill("+", C.CARD2, C.TEXT, 16f) {
            plus()
            refresh()
        }
        label.gravity = Gravity.CENTER
        r.addView(m, c.llp(c.dp(40), WRAP))
        r.addView(label, c.llp(c.dp(86), WRAP))
        r.addView(p, c.llp(c.dp(40), WRAP))
        return r
    }

    private fun label(t: String): TextView {
        val v = c.tv(t, 13f, C.SUB)
        v.minWidth = c.dp(60)
        return v
    }

    init {
        // ---- tampilan utama
        main.orientation = LinearLayout.VERTICAL
        val head = LinearLayout(c)
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(c.tv("💧 WaterReminder", 17f, C.TEXT, true))
        head.addView(View(c), c.llp(0, 1, 1f))
        head.addView(c.pill("Settings", C.CARD2, C.TEXT, 12f) {
            main.visibility = GONE
            sett.visibility = VISIBLE
            refresh()
        })
        main.addView(head, c.llp(MATCH, WRAP, 0f, 0, 0, 0, 8))
        val big = LinearLayout(c)
        big.gravity = Gravity.BOTTOM
        big.addView(tToday)
        tGoal.setPadding(c.dp(8), 0, 0, c.dp(4))
        big.addView(tGoal)
        main.addView(big)
        main.addView(prog, c.llp(MATCH, c.dp(14), 0f, 0, 8, 0, 4))
        main.addView(tNext, c.llp(WRAP, WRAP, 0f, 0, 4, 0, 2))
        main.addView(tSum)
        main.addView(tBottle, c.llp(WRAP, WRAP, 0f, 0, 2, 0, 0))
        val btns = LinearLayout(c)
        btns.addView(c.pill("Drank", C.ACCENT) {
            Nusa.water.drink()
            refresh()
        }, c.llp(WRAP, WRAP, 0f, 0, 0, 8, 0))
        btns.addView(c.pill("Refilled", C.CARD2) {
            Nusa.water.refill()
            refresh()
        }, c.llp(WRAP, WRAP, 0f, 0, 0, 8, 0))
        btns.addView(c.pill("Snooze", C.CARD2) {
            Nusa.water.snooze()
            refresh()
        })
        main.addView(btns, c.llp(WRAP, WRAP, 0f, 0, 10, 0, 0))
        addView(main, LayoutParams(MATCH, MATCH))

        // ---- pengaturan
        sett.orientation = LinearLayout.VERTICAL
        sett.visibility = GONE
        val sh = LinearLayout(c)
        sh.gravity = Gravity.CENTER_VERTICAL
        sh.addView(c.tv("Settings", 17f, C.TEXT, true))
        sh.addView(View(c), c.llp(0, 1, 1f))
        sh.addView(c.pill("Done", C.ACCENT, C.TEXT, 12f) {
            sett.visibility = GONE
            main.visibility = VISIBLE
            refresh()
        })
        sett.addView(sh, c.llp(MATCH, WRAP, 0f, 0, 0, 0, 6))

        val sv = ScrollView(c)
        val inner = LinearLayout(c)
        inner.orientation = LinearLayout.VERTICAL
        sv.addView(inner, LayoutParams(MATCH, WRAP))

        val r0 = LinearLayout(c)
        r0.gravity = Gravity.CENTER_VERTICAL
        r0.addView(label("Reminders"))
        bOn = c.pill("OFF", C.CARD2, C.TEXT, 12f) {
            Nusa.water.setOn(!Nusa.water.isOn)
            refresh()
        }
        r0.addView(bOn)
        inner.addView(r0, c.llp(MATCH, WRAP, 0f, 0, 2, 0, 6))

        val r1 = LinearLayout(c)
        r1.gravity = Gravity.CENTER_VERTICAL
        r1.addView(label("Bottle"))
        for (ml in Nusa.water.bottleOptions) {
            val t = c.tv("%.1f L".format(ml / 1000f), 13f, C.TEXT, true)
            t.setPadding(c.dp(12), c.dp(7), c.dp(12), c.dp(7))
            t.setOnClickListener {
                Nusa.water.chooseBottle(ml)
                refresh()
            }
            bottleChips.add(t)
            r1.addView(t, c.llp(WRAP, WRAP, 0f, 0, 0, 6, 0))
        }
        inner.addView(r1, c.llp(MATCH, WRAP, 0f, 0, 0, 0, 6))

        val r2 = LinearLayout(c)
        r2.gravity = Gravity.CENTER_VERTICAL
        r2.addView(label("Goal"))
        r2.addView(stepper(tGoalSet, { Nusa.water.goal = maxOf(1000, Nusa.water.goal - 250) }, { Nusa.water.goal = minOf(5000, Nusa.water.goal + 250) }))
        inner.addView(r2, c.llp(MATCH, WRAP, 0f, 0, 0, 0, 6))

        val r3 = LinearLayout(c)
        r3.gravity = Gravity.CENTER_VERTICAL
        r3.addView(label("Hours"))
        r3.addView(stepper(tStart, { Nusa.water.setHours(Nusa.water.startH - 1, Nusa.water.endH) }, { Nusa.water.setHours(Nusa.water.startH + 1, Nusa.water.endH) }))
        r3.addView(label("  to  "))
        r3.addView(stepper(tEnd, { Nusa.water.setHours(Nusa.water.startH, Nusa.water.endH - 1) }, { Nusa.water.setHours(Nusa.water.startH, Nusa.water.endH + 1) }))
        inner.addView(r3, c.llp(MATCH, WRAP, 0f, 0, 0, 0, 8))

        bReset = c.pill("Reset", C.CARD2, C.RED, 12f) {
            if (!confirm) {
                confirm = true
                postDelayed({
                    confirm = false
                    refresh()
                }, 3000)
            } else {
                confirm = false
                Nusa.water.reset()
            }
            refresh()
        }
        inner.addView(bReset, c.llp(WRAP, WRAP))
        sett.addView(sv, c.llp(MATCH, 0, 1f))
        addView(sett, LayoutParams(MATCH, MATCH))
    }

    override fun refresh() {
        val w = Nusa.water
        w.ensureToday()
        tToday.text = "${w.taken} ml"
        tGoal.text = "/ ${w.goal} ml"
        prog.fillColor = C.CYAN
        prog.frac = if (w.goal > 0) w.taken.toFloat() / w.goal else 0f
        tNext.text = w.nextText()
        tSum.text = "${w.reminders()} reminders · ${w.mlEach()} ml each · ${w.refillsPerDay()} refills"
        tBottle.text = "Bottle: ${w.inBottle} / ${w.bottle} ml"
        bOn.text = if (w.isOn) "ON" else "OFF"
        bOn.background = rounded(if (w.isOn) C.ACCENT else C.CARD2, c.dpf(100))
        for (i in bottleChips.indices) {
            val sel = w.bottleOptions[i] == w.bottle
            bottleChips[i].background = rounded(if (sel) C.ACCENT else C.CARD2, c.dpf(100))
            bottleChips[i].setTextColor(if (sel) C.TEXT else C.SUB)
        }
        tGoalSet.text = "${w.goal} ml"
        tStart.text = "%02d:00".format(w.startH)
        tEnd.text = "%02d:00".format(w.endH)
        bReset.text = if (confirm) "Sure?" else "Reset"
    }
}

// ------------------------------------------------------------------ SHELF

class ShelfPanel(private val c: Context) : FrameLayout(c), Refreshable {
    private val hint = c.tv("Drop files here · Drag out anytime", 13f, C.SUB)
    private val row = LinearLayout(c)
    private val frame = FrameLayout(c)
    private var sig = ""
    private var confirmClear = false
    private val bClear: TextView

    init {
        val col = LinearLayout(c)
        col.orientation = LinearLayout.VERTICAL
        val head = LinearLayout(c)
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(c.tv("📁 File Shelf", 17f, C.TEXT, true))
        head.addView(View(c), c.llp(0, 1, 1f))
        head.addView(c.pill("+ Add", C.ACCENT, C.TEXT, 12f) {
            val i = Intent(c, ShareReceiverActivity::class.java)
            i.action = "com.nusa.notch.PICK"
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            c.startActivity(i)
        }, c.llp(WRAP, WRAP, 0f, 0, 0, 6, 0))
        bClear = c.pill("Clear", C.CARD2, C.RED, 12f) {
            if (!confirmClear) {
                confirmClear = true
                postDelayed({
                    confirmClear = false
                    bClear.text = "Clear"
                }, 3000)
                bClear.text = "Sure?"
            } else {
                confirmClear = false
                bClear.text = "Clear"
                Nusa.shelf.clear()
                sig = ""
                refresh()
            }
        }
        head.addView(bClear)
        col.addView(head, c.llp(MATCH, WRAP, 0f, 0, 0, 0, 6))
        col.addView(hint, c.llp(WRAP, WRAP, 0f, 0, 0, 0, 8))
        val hs = HorizontalScrollView(c)
        hs.isHorizontalScrollBarEnabled = false
        row.orientation = LinearLayout.HORIZONTAL
        hs.addView(row, LayoutParams(WRAP, MATCH))
        frame.background = rounded(C.CARD, c.dpf(18))
        frame.setPadding(c.dp(10), c.dp(10), c.dp(10), c.dp(10))
        frame.addView(hs, LayoutParams(MATCH, MATCH))
        col.addView(frame, c.llp(MATCH, 0, 1f))
        addView(col, LayoutParams(MATCH, MATCH))
        setOnDragListener { _, e -> onDrag(e) }
    }

    private fun onDrag(e: DragEvent): Boolean {
        when (e.action) {
            DragEvent.ACTION_DRAG_STARTED -> return true
            DragEvent.ACTION_DRAG_ENTERED -> {
                hint.text = "Release to add"
                frame.background = rounded(C.CARD2, c.dpf(18))
            }
            DragEvent.ACTION_DRAG_EXITED, DragEvent.ACTION_DRAG_ENDED -> {
                hint.text = "Drop files here · Drag out anytime"
                frame.background = rounded(C.CARD, c.dpf(18))
            }
            DragEvent.ACTION_DROP -> {
                handleDrop(e)
                hint.text = "Drop files here · Drag out anytime"
                frame.background = rounded(C.CARD, c.dpf(18))
            }
        }
        return true
    }

    private fun handleDrop(e: DragEvent) {
        val clip = e.clipData ?: return
        var fail = 0
        for (i in 0 until clip.itemCount) {
            val item = clip.getItemAt(i)
            val uri = item.uri
            val txt = item.text?.toString()
            if (uri != null) {
                val sch = uri.scheme ?: ""
                if (sch == "http" || sch == "https") Nusa.shelf.addLink(uri.toString())
                else if (!Nusa.shelf.addUri(uri)) fail++
            } else if (txt != null && (txt.startsWith("http://") || txt.startsWith("https://"))) {
                Nusa.shelf.addLink(txt.trim())
            }
        }
        sig = ""
        refresh()
        if (fail > 0) {
            Bus.alert(Alert("Couldn't read that file", "Use Share → Nusa Shelf, or drop it inside the Nusa app", "!", C.RED, tab = 4))
        }
    }

    private fun emoji(f: File): String {
        if (Nusa.shelf.isLink(f)) return "🔗"
        return when (f.extension.lowercase()) {
            "png", "jpg", "jpeg", "gif", "webp", "heic", "bmp" -> "🖼"
            "mp4", "mkv", "mov", "webm", "avi" -> "🎞"
            "mp3", "flac", "wav", "m4a", "ogg", "aac" -> "🎵"
            "pdf" -> "📕"
            "doc", "docx", "txt", "md", "rtf" -> "📄"
            "xls", "xlsx", "csv" -> "📊"
            "ppt", "pptx" -> "📽"
            "zip", "rar", "7z", "tar", "gz" -> "🗜"
            "apk" -> "📦"
            else -> "📄"
        }
    }

    private fun open(f: File) {
        try {
            val i: Intent
            if (Nusa.shelf.isLink(f)) {
                val u = Nusa.shelf.linkTarget(f) ?: return
                i = Intent(Intent.ACTION_VIEW, Uri.parse(u))
            } else {
                val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "*/*"
                i = Intent(Intent.ACTION_VIEW)
                i.setDataAndType(Nusa.shelf.uriFor(f), mime)
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            c.startActivity(i)
        } catch (e: Exception) {
            Bus.alert(Alert("No app can open this", f.name, "!", C.ORANGE))
        }
    }

    private fun startDrag(v: View, f: File) {
        try {
            val clip: ClipData
            if (Nusa.shelf.isLink(f)) {
                clip = ClipData.newPlainText("link", Nusa.shelf.linkTarget(f) ?: "")
            } else {
                clip = ClipData.newUri(c.contentResolver, f.name, Nusa.shelf.uriFor(f))
            }
            val flags = View.DRAG_FLAG_GLOBAL or View.DRAG_FLAG_GLOBAL_URI_READ
            v.startDragAndDrop(clip, View.DragShadowBuilder(v), null, flags)
        } catch (e: Exception) {
        }
    }

    override fun refresh() {
        val items = Nusa.shelf.items()
        val s = items.joinToString("|") { it.name + it.lastModified() }
        if (s == sig) return
        sig = s
        row.removeAllViews()
        if (items.isEmpty()) {
            val e = c.tv("Shelf is empty", 14f, C.SUB)
            row.addView(e, c.llp(WRAP, WRAP, 0f, 6, 6, 0, 0))
            return
        }
        for (f in items) {
            val chip = FrameLayout(c)
            chip.background = rounded(C.CARD2, c.dpf(14))
            val col = LinearLayout(c)
            col.orientation = LinearLayout.VERTICAL
            col.gravity = Gravity.CENTER_HORIZONTAL
            col.setPadding(c.dp(8), c.dp(10), c.dp(8), c.dp(8))
            col.addView(c.tv(emoji(f), 30f))
            val n = c.tv(f.name, 11f, C.TEXT)
            n.maxLines = 2
            n.gravity = Gravity.CENTER
            n.ellipsize = TextUtils.TruncateAt.MIDDLE
            col.addView(n, c.llp(c.dp(84), WRAP, 0f, 0, 6, 0, 0))
            chip.addView(col, LayoutParams(WRAP, WRAP))
            val x = c.tv("✕", 12f, C.SUB)
            x.setPadding(c.dp(8), c.dp(4), c.dp(8), c.dp(4))
            x.setOnClickListener {
                Nusa.shelf.remove(f)
                sig = ""
                refresh()
            }
            val xl = LayoutParams(WRAP, WRAP)
            xl.gravity = Gravity.TOP or Gravity.END
            chip.addView(x, xl)
            chip.setOnClickListener { open(f) }
            chip.setOnLongClickListener {
                startDrag(chip, f)
                true
            }
            row.addView(chip, c.llp(WRAP, WRAP, 0f, 0, 0, 8, 0))
        }
    }
}
