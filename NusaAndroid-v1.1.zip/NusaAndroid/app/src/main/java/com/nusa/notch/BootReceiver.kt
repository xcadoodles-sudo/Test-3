package com.nusa.notch

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val a = i.action
        if (a == Intent.ACTION_BOOT_COMPLETED || a == Intent.ACTION_MY_PACKAGE_REPLACED) {
            if (Nusa.prefs.startOnBoot && Settings.canDrawOverlays(c)) {
                try {
                    NotchService.start(c)
                } catch (e: Exception) {
                }
            }
        }
    }
}
