package com.nusa.notch

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.random.Random

const val MATCH = -1
const val WRAP = -2

object C {
    val BLACK = 0xFF000000.toInt()
    val APP_BG = 0xFF0B0B10.toInt()
    val CARD = 0xFF1C1C21.toInt()
    val CARD2 = 0xFF2A2A31.toInt()
    val TEXT = 0xFFFFFFFF.toInt()
    val SUB = 0xFF9A9AA4.toInt()
    val ACCENT = 0xFF8B7BFF.toInt()
    val GREEN = 0xFF30D158.toInt()
    val RED = 0xFFFF453A.toInt()
    val BLUE = 0xFF0A84FF.toInt()
    val ORANGE = 0xFFFF9F0A.toInt()
    val CYAN = 0xFF40C8E0.toInt()
}

interface Refreshable {
    fun refresh()
}

fun Context.dp(v: Number): Int = (v.toFloat() * resources.displayMetrics.density + 0.5f).toInt()
fun Context.dpf(v: Number): Float = v.toFloat() * resources.displayMetrics.density

/** LayoutParams untuk LinearLayout. w/h dalam px (pakai dp() / MATCH / WRAP), margin dalam dp. */
fun Context.llp(w: Int, h: Int, weight: Float = 0f, ml: Int = 0, mt: Int = 0, mr: Int = 0, mb: Int = 0): LinearLayout.LayoutParams {
    val p = LinearLayout.LayoutParams(w, h, weight)
    p.setMargins(dp(ml), dp(mt), dp(mr), dp(mb))
    return p
}

fun rounded(color: Int, radiusPx: Float): GradientDrawable {
    val g = GradientDrawable()
    g.setColor(color)
    g.cornerRadius = radiusPx
    return g
}

fun Context.tv(text: String, sp: Float, color: Int = C.TEXT, bold: Boolean = false): TextView {
    val t = TextView(this)
    t.text = text
    t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
    t.setTextColor(color)
    if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
    t.includeFontPadding = false
    return t
}

fun Context.pill(text: String, bg: Int, fg: Int = C.TEXT, sp: Float = 13f, onClick: () -> Unit): TextView {
    val t = tv(text, sp, fg, true)
    t.gravity = Gravity.CENTER
    t.setPadding(dp(14), dp(8), dp(14), dp(8))
    t.background = rounded(bg, dpf(100))
    t.setOnClickListener { onClick() }
    return t
}

fun View.roundClip(radiusPx: Float) {
    outlineProvider = object : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) {
            outline.setRoundRect(0, 0, view.width, view.height, radiusPx)
        }
    }
    clipToOutline = true
}

fun fmtTime(ms: Long): String {
    val s = (if (ms < 0) 0L else ms) / 1000
    return "%d:%02d".format(s / 60, s % 60)
}

fun fmtCountdown(ms: Long): String {
    val s = ((if (ms < 0) 0L else ms) + 999) / 1000
    return "%02d:%02d".format(s / 60, s % 60)
}

/** Equalizer kecil (bar naik-turun) seperti Dynamic Island saat musik jalan. */
class EqView(c: Context) : View(c) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val lv = floatArrayOf(0.4f, 0.8f, 0.5f, 0.7f)
    var active = true
    private val loop = object : Runnable {
        override fun run() {
            if (visibility == VISIBLE) {
                if (active) {
                    for (i in lv.indices) lv[i] = 0.25f + Random.nextFloat() * 0.75f
                } else {
                    for (i in lv.indices) lv[i] = 0.25f
                }
                invalidate()
            }
            postDelayed(this, 160)
        }
    }

    init {
        paint.color = C.ACCENT
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        post(loop)
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(loop)
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        val n = lv.size
        val bw = width / (n * 2f - 1f)
        for (i in 0 until n) {
            val h = height * lv[i]
            val x = i * bw * 2f
            canvas.drawRoundRect(x, height - h, x + bw, height.toFloat(), bw / 2f, bw / 2f, paint)
        }
    }
}

/** Garis progress tipis; bisa disentuh untuk seek kalau onSeek di-set. */
class ProgressLine(private val c: Context) : View(c) {
    var frac: Float = 0f
        set(v) {
            field = v.coerceIn(0f, 1f)
            invalidate()
        }
    var fillColor: Int = C.TEXT
        set(v) {
            field = v
            invalidate()
        }
    var onSeek: ((Float) -> Unit)? = null
    private val track = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        track.color = 0x33FFFFFF
    }

    override fun onDraw(canvas: Canvas) {
        val t = c.dpf(3)
        val cy = height / 2f
        canvas.drawRoundRect(0f, cy - t, width.toFloat(), cy + t, t, t, track)
        fill.color = fillColor
        canvas.drawRoundRect(0f, cy - t, width * frac, cy + t, t, t, fill)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val cb = onSeek ?: return false
        if (e.action == MotionEvent.ACTION_UP && width > 0) {
            cb((e.x / width).coerceIn(0f, 1f))
        }
        return true
    }
}

/** Maskot kucing "Nusa" yang berkedip. */
class PetView(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var blink = 0f
    private val ui = Handler(Looper.getMainLooper())
    private val blinkRun = object : Runnable {
        override fun run() {
            val a = ValueAnimator.ofFloat(0f, 1f, 0f)
            a.duration = 190
            a.addUpdateListener {
                blink = it.animatedValue as Float
                invalidate()
            }
            a.start()
            ui.postDelayed(this, 2500L + Random.nextLong(3500L))
        }
    }

    fun wiggle() {
        ObjectAnimator.ofFloat(this, "rotation", 0f, -16f, 16f, -8f, 0f).setDuration(500).start()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        ui.postDelayed(blinkRun, 1500)
    }

    override fun onDetachedFromWindow() {
        ui.removeCallbacks(blinkRun)
        super.onDetachedFromWindow()
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val rect = RectF(w * 0.06f, h * 0.26f, w * 0.94f, h * 0.96f)
        p.shader = null
        p.style = Paint.Style.FILL
        p.color = 0xFF2B2B33.toInt()
        cv.drawRoundRect(rect, w * 0.34f, w * 0.34f, p)
        val e1 = Path()
        e1.moveTo(w * 0.08f, h * 0.52f)
        e1.lineTo(w * 0.14f, h * 0.06f)
        e1.lineTo(w * 0.44f, h * 0.30f)
        e1.close()
        cv.drawPath(e1, p)
        val e2 = Path()
        e2.moveTo(w * 0.92f, h * 0.52f)
        e2.lineTo(w * 0.86f, h * 0.06f)
        e2.lineTo(w * 0.56f, h * 0.30f)
        e2.close()
        cv.drawPath(e2, p)
        p.shader = LinearGradient(0f, h * 0.60f, 0f, h, 0x007C6CFF, 0xDD4A8CFF.toInt(), Shader.TileMode.CLAMP)
        cv.drawRoundRect(rect, w * 0.34f, w * 0.34f, p)
        p.shader = null
        p.color = 0xFFEAF1FF.toInt()
        val ry = h * 0.11f * (1f - 0.9f * blink)
        cv.drawOval(RectF(w * 0.23f, h * 0.60f - ry, w * 0.41f, h * 0.60f + ry), p)
        cv.drawOval(RectF(w * 0.59f, h * 0.60f - ry, w * 0.77f, h * 0.60f + ry), p)
    }
}

/** Panel yang perlu tahu kapan sedang terlihat (untuk start/stop polling). */
interface PanelLife {
    fun onVisible(v: Boolean)
}

/** Chart garis + area gradien ala TradingView. Sentuh/geser untuk melihat harga per titik. */
class ChartView(private val c: Context) : View(c) {
    private var closes = DoubleArray(0)
    private var times = LongArray(0)
    private var base = Double.NaN
    private var color = C.GREEN
    private var dec = 2
    private var touchX = -1f
    private var intraday = true

    private val line = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dash = Paint(Paint.ANTI_ALIAS_FLAG)
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        line.style = Paint.Style.STROKE
        line.strokeWidth = c.dpf(1.8f)
        line.strokeJoin = Paint.Join.ROUND
        line.strokeCap = Paint.Cap.ROUND
        dash.style = Paint.Style.STROKE
        dash.strokeWidth = c.dpf(1)
        dash.color = 0x55FFFFFF
        dash.pathEffect = DashPathEffect(floatArrayOf(c.dpf(3), c.dpf(4)), 0f)
        txt.textSize = c.dpf(10)
        txt.color = 0x99FFFFFF.toInt()
    }

    fun setData(t: LongArray, v: DoubleArray, baseline: Double, up: Boolean, decimals: Int, intra: Boolean) {
        times = t
        closes = v
        base = baseline
        color = if (up) C.GREEN else C.RED
        dec = decimals
        intraday = intra
        invalidate()
    }

    private fun fmtTime(ts: Long): String {
        val f = java.text.SimpleDateFormat(if (intraday) "HH:mm" else "d MMM", java.util.Locale.getDefault())
        return f.format(java.util.Date(ts * 1000))
    }

    override fun onDraw(cv: Canvas) {
        val n = closes.size
        val w = width.toFloat()
        val h = height.toFloat()
        if (n < 2 || w <= 0f) {
            txt.textAlign = Paint.Align.CENTER
            cv.drawText("Loading chart…", w / 2f, h / 2f, txt)
            return
        }
        var lo = closes[0]
        var hi = closes[0]
        for (v in closes) {
            if (v < lo) lo = v
            if (v > hi) hi = v
        }
        if (!base.isNaN() && intraday) {
            lo = minOf(lo, base)
            hi = maxOf(hi, base)
        }
        if (hi - lo < 1e-9) {
            hi += 1.0
            lo -= 1.0
        }
        val padT = c.dpf(14)
        val padB = c.dpf(4)
        val padR = c.dpf(46)
        val cw = w - padR
        fun xs(i: Int) = cw * i / (n - 1)
        fun ys(v: Double) = (padT + (hi - v) / (hi - lo) * (h - padT - padB)).toFloat()

        val path = Path()
        for (i in 0 until n) {
            val x = xs(i)
            val y = ys(closes[i])
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        val area = Path(path)
        area.lineTo(xs(n - 1), h)
        area.lineTo(0f, h)
        area.close()
        fill.shader = LinearGradient(0f, padT, 0f, h, (color and 0x00FFFFFF) or 0x55000000, (color and 0x00FFFFFF), Shader.TileMode.CLAMP)
        cv.drawPath(area, fill)
        line.color = color
        cv.drawPath(path, line)

        if (!base.isNaN() && intraday) {
            val by = ys(base)
            cv.drawLine(0f, by, cw, by, dash)
        }
        txt.textAlign = Paint.Align.LEFT
        cv.drawText(fmtPrice(hi, dec), cw + c.dpf(4), padT + c.dpf(3), txt)
        cv.drawText(fmtPrice(lo, dec), cw + c.dpf(4), h - padB, txt)

        val idx = if (touchX >= 0f) (touchX / cw * (n - 1)).toInt().coerceIn(0, n - 1) else n - 1
        val px = xs(idx)
        val py = ys(closes[idx])
        dot.color = color
        if (touchX >= 0f) {
            dash.color = 0x88FFFFFF.toInt()
            cv.drawLine(px, 0f, px, h, dash)
            dash.color = 0x55FFFFFF
            txt.color = C.TEXT
            txt.textAlign = if (px > cw / 2f) Paint.Align.RIGHT else Paint.Align.LEFT
            cv.drawText(fmtPrice(closes[idx], dec) + "  " + fmtTime(times[idx]), if (px > cw / 2f) px - c.dpf(6) else px + c.dpf(6), c.dpf(10), txt)
            txt.color = 0x99FFFFFF.toInt()
        }
        cv.drawCircle(px, py, c.dpf(3.2f), dot)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.action) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                touchX = e.x
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                touchX = -1f
                invalidate()
            }
        }
        return true
    }
}
