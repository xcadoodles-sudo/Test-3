package com.nusa.notch

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.random.Random

const val MATCH = -1
const val WRAP = -2

object C {
    val BLACK = 0xFF000000.toInt()
    val APP_BG = 0xFF0B0B10.toInt()
    val CARD = 0xFF1C1C21.toInt()
    val CARD2 = 0xFF2A2A31.toInt()
    val TEXT = 0xFFFFFFFF.toInt()
    val SUB = 0xFF9A9AA4.toInt()
    val ACCENT = 0xFF8B7BFF.toInt()
    val GREEN = 0xFF30D158.toInt()
    val RED = 0xFFFF453A.toInt()
    val BLUE = 0xFF0A84FF.toInt()
    val ORANGE = 0xFFFF9F0A.toInt()
    val CYAN = 0xFF40C8E0.toInt()
}

interface Refreshable {
    fun refresh()
}

fun Context.dp(v: Number): Int = (v.toFloat() * resources.displayMetrics.density + 0.5f).toInt()
fun Context.dpf(v: Number): Float = v.toFloat() * resources.displayMetrics.density

/** LayoutParams untuk LinearLayout. w/h dalam px (pakai dp() / MATCH / WRAP), margin dalam dp. */
fun Context.llp(w: Int, h: Int, weight: Float = 0f, ml: Int = 0, mt: Int = 0, mr: Int = 0, mb: Int = 0): LinearLayout.LayoutParams {
    val p = LinearLayout.LayoutParams(w, h, weight)
    p.setMargins(dp(ml), dp(mt), dp(mr), dp(mb))
    return p
}

fun rounded(color: Int, radiusPx: Float): GradientDrawable {
    val g = GradientDrawable()
    g.setColor(color)
    g.cornerRadius = radiusPx
    return g
}

fun Context.tv(text: String, sp: Float, color: Int = C.TEXT, bold: Boolean = false): TextView {
    val t = TextView(this)
    t.text = text
    t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
    t.setTextColor(color)
    if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
    t.includeFontPadding = false
    return t
}

fun Context.pill(text: String, bg: Int, fg: Int = C.TEXT, sp: Float = 13f, onClick: () -> Unit): TextView {
    val t = tv(text, sp, fg, true)
    t.gravity = Gravity.CENTER
    t.setPadding(dp(14), dp(8), dp(14), dp(8))
    t.background = rounded(bg, dpf(100))
    t.setOnClickListener { onClick() }
    return t
}

fun View.roundClip(radiusPx: Float) {
    outlineProvider = object : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) {
            outline.setRoundRect(0, 0, view.width, view.height, radiusPx)
        }
    }
    clipToOutline = true
}

fun fmtTime(ms: Long): String {
    val s = (if (ms < 0) 0L else ms) / 1000
    return "%d:%02d".format(s / 60, s % 60)
}

fun fmtCountdown(ms: Long): String {
    val s = ((if (ms < 0) 0L else ms) + 999) / 1000
    return "%02d:%02d".format(s / 60, s % 60)
}

/** Equalizer kecil (bar naik-turun) seperti Dynamic Island saat musik jalan. */
class EqView(c: Context) : View(c) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val lv = floatArrayOf(0.4f, 0.8f, 0.5f, 0.7f)
    var active = true
    private val loop = object : Runnable {
        override fun run() {
            if (visibility == VISIBLE) {
                if (active) {
                    for (i in lv.indices) lv[i] = 0.25f + Random.nextFloat() * 0.75f
                } else {
                    for (i in lv.indices) lv[i] = 0.25f
                }
                invalidate()
            }
            postDelayed(this, 160)
        }
    }

    init {
        paint.color = C.ACCENT
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        post(loop)
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(loop)
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        val n = lv.size
        val bw = width / (n * 2f - 1f)
        for (i in 0 until n) {
            val h = height * lv[i]
            val x = i * bw * 2f
            canvas.drawRoundRect(x, height - h, x + bw, height.toFloat(), bw / 2f, bw / 2f, paint)
        }
    }
}

/** Garis progress tipis; bisa disentuh untuk seek kalau onSeek di-set. */
class ProgressLine(private val c: Context) : View(c) {
    var frac: Float = 0f
        set(v) {
            field = v.coerceIn(0f, 1f)
            invalidate()
        }
    var fillColor: Int = C.TEXT
        set(v) {
            field = v
            invalidate()
        }
    var onSeek: ((Float) -> Unit)? = null
    private val track = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        track.color = 0x33FFFFFF
    }

    override fun onDraw(canvas: Canvas) {
        val t = c.dpf(3)
        val cy = height / 2f
        canvas.drawRoundRect(0f, cy - t, width.toFloat(), cy + t, t, t, track)
        fill.color = fillColor
        canvas.drawRoundRect(0f, cy - t, width * frac, cy + t, t, t, fill)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val cb = onSeek ?: return false
        if (e.action == MotionEvent.ACTION_UP && width > 0) {
            cb((e.x / width).coerceIn(0f, 1f))
        }
        return true
    }
}

/** Maskot kucing "Nusa" yang berkedip. */
class PetView(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var blink = 0f
    private val ui = Handler(Looper.getMainLooper())
    private val blinkRun = object : Runnable {
        override fun run() {
            val a = ValueAnimator.ofFloat(0f, 1f, 0f)
            a.duration = 190
            a.addUpdateListener {
                blink = it.animatedValue as Float
                invalidate()
            }
            a.start()
            ui.postDelayed(this, 2500L + Random.nextLong(3500L))
        }
    }

    fun wiggle() {
        ObjectAnimator.ofFloat(this, "rotation", 0f, -16f, 16f, -8f, 0f).setDuration(500).start()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        ui.postDelayed(blinkRun, 1500)
    }

    override fun onDetachedFromWindow() {
        ui.removeCallbacks(blinkRun)
        super.onDetachedFromWindow()
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val rect = RectF(w * 0.06f, h * 0.26f, w * 0.94f, h * 0.96f)
        p.shader = null
        p.style = Paint.Style.FILL
        p.color = 0xFF2B2B33.toInt()
        cv.drawRoundRect(rect, w * 0.34f, w * 0.34f, p)
        val e1 = Path()
        e1.moveTo(w * 0.08f, h * 0.52f)
        e1.lineTo(w * 0.14f, h * 0.06f)
        e1.lineTo(w * 0.44f, h * 0.30f)
        e1.close()
        cv.drawPath(e1, p)
        val e2 = Path()
        e2.moveTo(w * 0.92f, h * 0.52f)
        e2.lineTo(w * 0.86f, h * 0.06f)
        e2.lineTo(w * 0.56f, h * 0.30f)
        e2.close()
        cv.drawPath(e2, p)
        p.shader = LinearGradient(0f, h * 0.60f, 0f, h, 0x007C6CFF, 0xDD4A8CFF.toInt(), Shader.TileMode.CLAMP)
        cv.drawRoundRect(rect, w * 0.34f, w * 0.34f, p)
        p.shader = null
        p.color = 0xFFEAF1FF.toInt()
        val ry = h * 0.11f * (1f - 0.9f * blink)
        cv.drawOval(RectF(w * 0.23f, h * 0.60f - ry, w * 0.41f, h * 0.60f + ry), p)
        cv.drawOval(RectF(w * 0.59f, h * 0.60f - ry, w * 0.77f, h * 0.60f + ry), p)
    }
}
