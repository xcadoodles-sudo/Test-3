package com.nusa.notch

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Outline
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.Choreographer
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.animation.Interpolator
import android.view.animation.PathInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Notch yang menempel di tepi atas layar (atas datar, bawah melengkung).
 * COMPACT : pil (maskot / album art di kiri, equalizer di kanan)
 * ALERT   : melebar sebentar untuk notifikasi
 * PANEL   : ketuk pil -> Music / Device / Markets / Calendar / Shelf
 *
 * Animasi: jendela dan isi di-layout SEKALI di awal & akhir transisi. Selama animasi hanya
 * outline (clip rounded-rect) yang berubah, jadi tidak ada relayout / IPC jendela per frame.
 * Easing mulus tanpa spring/overshoot.
 */
@SuppressLint("ViewConstructor", "ClickableViewAccessibility")
class NotchView(private val svc: Context, private val media: MediaWatcher) : FrameLayout(svc) {
    enum class S { COMPACT, ALERT, PANEL }

    companion object {
        private const val TABS_H = 38
        private const val BODY_PAD_V = 16 // 4 atas + 12 bawah
        private const val PANEL_W = 620
        private const val ALERT_H = 68
        private val TAB_H = intArrayOf(196, 196, 290, 290, 290)
    }

    private val ui = Handler(Looper.getMainLooper())
    var state = S.COMPACT
        private set

    private val box = FrameLayout(svc)
    private val bg = GradientDrawable()
    private var tint = C.BLACK
    private var tintAnim: ValueAnimator? = null
    private var tintArt: Bitmap? = null
    private var tintCache = C.BLACK

    // ukuran/radius yang tampil sekarang (px) — dianimasikan, dipakai outline
    private var vW = 0f
    private var vH = 0f
    private var vR = 0f
    private var flat = true
    private val easeOut = PathInterpolator(0.2f, 0.9f, 0.25f, 1f)
    private val easeInOut = PathInterpolator(0.4f, 0f, 0.2f, 1f)
    private var shown: View? = null
    private val glow = GlowView(svc)
    private val tabGlow = arrayOf(
        intArrayOf(0xFFFF9A3D.toInt(), 0xFFFF3D7F.toInt()), // music: sunrise oranye -> pink
        intArrayOf(0xFF3DDCFF.toInt(), 0xFF3D6BFF.toInt()), // device: cyan -> biru
        intArrayOf(0xFF35E08A.toInt(), 0xFF12A39A.toInt()), // markets: hijau -> teal
        intArrayOf(0xFFB06BFF.toInt(), 0xFFFF5FB5.toInt()), // calendar: ungu -> magenta
        intArrayOf(0xFFFFD04D.toInt(), 0xFFFF8A3D.toInt())  // shelf: kuning -> oranye
    )

    // --- engine morph (Choreographer): dt per frame dibatasi, jadi frame yang tersendat tidak bikin lompat
    private val choreo = Choreographer.getInstance()
    private var mRunning = false
    private var mDur = 1f
    private var mEl = 0f
    private var mLast = 0L
    private var mW0 = 0f
    private var mH0 = 0f
    private var mR0 = 0f
    private var mW1 = 0
    private var mH1 = 0
    private var mR1 = 0f
    private var mT0 = 0
    private var mT1 = 0
    private var mEase: Interpolator = easeOut
    private var fOut: List<View> = emptyList()
    private var fIn: List<View> = emptyList()
    private var fOutA = FloatArray(0)
    private var fInA = FloatArray(0)
    private var pendingGlow: IntArray? = null
    private val argb = ArgbEvaluator()

    private val compact = LinearLayout(svc)
    private val alertBox = LinearLayout(svc)
    private val panelBox = LinearLayout(svc)

    // --- compact
    private val pet = PetView(svc)
    private val miniArt = ImageView(svc)
    private val gap = View(svc)
    private val eq = EqView(svc)
    private var lastMiniArt: Bitmap? = null

    // --- alert
    private val aIconBox = FrameLayout(svc)
    private val aGlyph = svc.tv("", 18f, C.TEXT, true)
    private val aImg = ImageView(svc)
    private val aTitle = svc.tv("", 15f, C.TEXT, true)
    private val aSub = svc.tv("", 13f, 0x99FFFFFF.toInt())
    private var current: Alert? = null
    private val queue = java.util.ArrayDeque<Alert>()

    // --- panel
    private val tabsRow = LinearLayout(svc)
    private val body = FrameLayout(svc)
    private val music = MusicPanel(svc, media)
    private val device = DevicePanel(svc)
    private val markets = MarketsPanel(svc)
    private val calendar = CalendarPanel(svc)
    private val shelf = ShelfPanel(svc)
    private val panels: List<View> = listOf(music, device, markets, calendar, shelf)
    private val tabIcons = listOf("♪", "📱", "📈", "📅", "📁")
    private val tabViews = ArrayList<TextView>()
    private var tab = 0

    private val endAlert = Runnable {
        current = null
        val n = queue.poll()
        if (n != null) showAlert(n) else showCompact()
    }

    private val uiTick = object : Runnable {
        override fun run() {
            val busy = mRunning
            when (state) {
                S.COMPACT -> {
                    updateCompact()
                    if (!busy) fitCompact()
                }
                S.PANEL -> if (!busy) {
                    (panels[tab] as Refreshable).refresh()
                    animateTint(wantedTint())
                }
                S.ALERT -> {
                }
            }
            ui.postDelayed(this, 500)
        }
    }

    init {
        flat = Nusa.prefs.topOffset == 0
        setTint(C.BLACK)
        box.background = bg
        box.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                val cx = view.width / 2f
                val l = Math.round(cx - vW / 2f)
                val r = Math.round(cx + vW / 2f)
                val top = if (flat) -Math.round(vR) - 2 else 0
                outline.setRoundRect(l, top, r, Math.round(vH), vR)
            }
        }
        box.clipToOutline = true

        box.addView(glow, LayoutParams(MATCH, MATCH))

        // ---------- compact: kiri maskot/art, kanan equalizer, tengah kosong (seperti notch MacBook)
        compact.orientation = LinearLayout.HORIZONTAL
        compact.gravity = Gravity.CENTER_VERTICAL
        compact.setPadding(svc.dp(12), 0, svc.dp(12), 0)
        compact.addView(pet, LinearLayout.LayoutParams(svc.dp(20), svc.dp(20)))
        miniArt.scaleType = ImageView.ScaleType.CENTER_CROP
        miniArt.roundClip(svc.dpf(6))
        compact.addView(miniArt, LinearLayout.LayoutParams(svc.dp(20), svc.dp(20)))
        compact.addView(gap, LinearLayout.LayoutParams(svc.dp(36), 1, 1f))
        compact.addView(eq, LinearLayout.LayoutParams(svc.dp(17), svc.dp(13)))
        compact.setOnClickListener {
            showPanel(if (media.hasSession && media.playing) 0 else Nusa.prefs.lastTab.coerceIn(0, panels.size - 1))
        }
        box.addView(compact, LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.CENTER_HORIZONTAL))

        // ---------- alert
        alertBox.orientation = LinearLayout.HORIZONTAL
        alertBox.gravity = Gravity.CENTER_VERTICAL
        alertBox.setPadding(svc.dp(14), 0, svc.dp(18), 0)
        aGlyph.gravity = Gravity.CENTER
        aIconBox.addView(aGlyph, LayoutParams(MATCH, MATCH))
        aImg.scaleType = ImageView.ScaleType.FIT_CENTER
        aImg.roundClip(svc.dpf(10))
        aIconBox.addView(aImg, LayoutParams(MATCH, MATCH))
        alertBox.addView(aIconBox, svc.llp(svc.dp(40), svc.dp(40)))
        val tcol = LinearLayout(svc)
        tcol.orientation = LinearLayout.VERTICAL
        aTitle.maxLines = 1
        aTitle.ellipsize = TextUtils.TruncateAt.END
        aSub.maxLines = 1
        aSub.ellipsize = TextUtils.TruncateAt.END
        tcol.addView(aTitle)
        tcol.addView(aSub, svc.llp(WRAP, WRAP, 0f, 0, 3, 0, 0))
        alertBox.addView(tcol, svc.llp(0, WRAP, 1f, 12, 0, 0, 0))
        alertBox.setOnClickListener {
            val a = current
            ui.removeCallbacks(endAlert)
            queue.clear()
            current = null
            a?.onClick?.invoke()
            if (a != null && a.tab >= 0) showPanel(a.tab) else showCompact()
        }
        alertBox.visibility = GONE
        box.addView(alertBox, LayoutParams(svc.dp(380), svc.dp(ALERT_H), Gravity.TOP or Gravity.CENTER_HORIZONTAL))

        // ---------- panel: strip ikon tab di atas, isi di bawah
        panelBox.orientation = LinearLayout.VERTICAL
        tabsRow.orientation = LinearLayout.HORIZONTAL
        tabsRow.gravity = Gravity.CENTER_VERTICAL
        tabsRow.setPadding(svc.dp(14), 0, svc.dp(10), 0)
        for (i in tabIcons.indices) {
            val t = svc.tv(tabIcons[i], 16f, C.TEXT, true)
            t.gravity = Gravity.CENTER
            t.setOnClickListener { selectTab(i) }
            tabViews.add(t)
            tabsRow.addView(t, svc.llp(0, svc.dp(30), 1f, 4, 0, 4, 0))
        }
        val close = svc.tv("⌃", 18f, 0x99FFFFFF.toInt(), true)
        close.setPadding(svc.dp(12), svc.dp(2), svc.dp(4), svc.dp(2))
        close.setOnClickListener { showCompact() }
        tabsRow.addView(close)
        panelBox.addView(tabsRow, svc.llp(MATCH, svc.dp(TABS_H)))
        body.setPadding(svc.dp(18), svc.dp(4), svc.dp(18), svc.dp(12))
        for (i in panels.indices) {
            // tinggi isi tiap panel tetap (sesuai tabnya) -> tidak ada relayout saat pindah tab
            val ph = svc.dp(TAB_H[i] - TABS_H - BODY_PAD_V)
            panels[i].visibility = GONE
            body.addView(panels[i], LayoutParams(MATCH, ph, Gravity.TOP))
        }
        panelBox.addView(body, svc.llp(MATCH, 0, 1f))
        panelBox.visibility = GONE
        box.addView(panelBox, LayoutParams(svc.dp(PANEL_W), svc.dp(TAB_H.max()), Gravity.TOP or Gravity.CENTER_HORIZONTAL))

        val (w, h) = compactSize()
        vW = w.toFloat()
        vH = h.toFloat()
        vR = compactR(h)
        setCompactLp(w, h)
        shown = compact
        addView(box, LayoutParams(w, h, Gravity.TOP or Gravity.CENTER_HORIZONTAL))
        updateCompact()
    }

    // ------------------------------------------------------------ util

    private fun screenW(): Int {
        return if (Build.VERSION.SDK_INT >= 30) {
            (svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager).currentWindowMetrics.bounds.width()
        } else {
            resources.displayMetrics.widthPixels
        }
    }

    private fun setTint(c: Int) {
        tint = c
        val dark = Color.rgb((Color.red(c) * 0.5f).toInt(), (Color.green(c) * 0.5f).toInt(), (Color.blue(c) * 0.5f).toInt())
        bg.orientation = GradientDrawable.Orientation.LEFT_RIGHT
        bg.colors = intArrayOf(c, dark)
    }

    private fun tintFrom(art: Bitmap): Int {
        if (art === tintArt) return tintCache
        var out = C.BLACK
        try {
            val px = Bitmap.createScaledBitmap(art, 1, 1, true).getPixel(0, 0)
            val hsv = FloatArray(3)
            Color.colorToHSV(px, hsv)
            hsv[1] = (hsv[1] * 1.15f).coerceAtMost(0.85f)
            hsv[2] = 0.30f
            out = Color.HSVToColor(hsv)
        } catch (e: Exception) {
        }
        tintArt = art
        tintCache = out
        return out
    }

    private fun wantedTint(): Int {
        if (state == S.PANEL && tab == 0 && media.hasSession) {
            val art = media.art
            if (art != null) return tintFrom(art)
        }
        return C.BLACK
    }

    private fun animateTint(target: Int) {
        if (target == tint) return
        if (mRunning) return
        if (tintAnim?.isRunning == true) return
        val a = ValueAnimator.ofArgb(tint, target)
        a.duration = 350
        a.interpolator = easeInOut
        a.addUpdateListener { setTint(it.animatedValue as Int) }
        a.start()
        tintAnim = a
    }

    private fun smooth(x: Float): Float {
        val u = x.coerceIn(0f, 1f)
        return u * u * (3f - 2f * u)
    }

    private val frameCb = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!mRunning) return
            if (mLast == 0L) {
                // frame pertama dilewati: di sinilah layout/relayout jendela terjadi
                mLast = frameTimeNanos
                pendingGlow?.let { glow.flash(it[0], it[1]) }
                pendingGlow = null
                choreo.postFrameCallback(this)
                return
            }
            val dt = ((frameTimeNanos - mLast) / 1_000_000f).coerceIn(0f, 24f)
            mLast = frameTimeNanos
            mEl += dt
            val u = (mEl / mDur).coerceAtMost(1f)
            applyMorph(u)
            if (u >= 1f) finishMorph() else choreo.postFrameCallback(this)
        }
    }

    private fun applyMorph(u: Float) {
        val f = mEase.getInterpolation(u)
        vW = mW0 + (mW1 - mW0) * f
        vH = mH0 + (mH1 - mH0) * f
        vR = mR0 + (mR1 - mR0) * f
        if (mT1 != mT0) setTint(argb.evaluate(f, mT0, mT1) as Int)
        val so = smooth(u / 0.4f)
        for (i in fOut.indices) fOut[i].alpha = fOutA[i] * (1f - so)
        val si = smooth((u - 0.2f) / 0.6f)
        for (i in fIn.indices) fIn[i].alpha = fInA[i] + (1f - fInA[i]) * si
        glow.setVisible(vW, vH)
        box.invalidateOutline()
    }

    private fun finishMorph() {
        mRunning = false
        vW = mW1.toFloat()
        vH = mH1.toFloat()
        vR = mR1
        if (mT1 != tint) setTint(mT1)
        for (v in fOut) {
            if (shown !== v && !fIn.contains(v)) v.visibility = GONE
            v.alpha = 1f
        }
        for (v in fIn) v.alpha = 1f
        fOut = emptyList()
        fIn = emptyList()
        val lp = box.layoutParams
        if (lp.width != mW1 || lp.height != mH1) {
            lp.width = mW1
            lp.height = mH1
            box.layoutParams = lp
        }
        glow.setVisible(vW, vH)
        box.invalidateOutline()
    }

    /**
     * Morph bentuk notch + crossfade isi. Box di-layout sekali ke ukuran max(lama, baru) di awal,
     * lalu hanya outline (rect + radius) yang dianimasikan di GPU; di akhir box di-snap ke ukuran final.
     */
    private fun startMorph(
        w: Int, h: Int, r: Float, dur: Long, tintTo: Int, ease: Interpolator,
        outs: List<View> = emptyList(), ins: List<View> = emptyList(), glowColors: IntArray? = null
    ) {
        if (mRunning) {
            choreo.removeFrameCallback(frameCb)
            mRunning = false
            for (v in fOut) {
                if (!ins.contains(v) && shown !== v) v.visibility = GONE
                if (!ins.contains(v)) v.alpha = 1f
            }
        }
        tintAnim?.cancel()
        val lp = box.layoutParams
        val nw = maxOf(w, Math.ceil(vW.toDouble()).toInt())
        val nh = maxOf(h, Math.ceil(vH.toDouble()).toInt())
        if (lp.width != nw || lp.height != nh) {
            lp.width = nw
            lp.height = nh
            box.layoutParams = lp
        }
        mW0 = vW
        mH0 = vH
        mR0 = vR
        mW1 = w
        mH1 = h
        mR1 = r
        mT0 = tint
        mT1 = tintTo
        mEase = ease
        mDur = dur.toFloat()
        mEl = 0f
        mLast = 0L
        fOut = outs.filter { it.visibility == VISIBLE }
        fIn = ins
        fOutA = FloatArray(fOut.size) { fOut[it].alpha }
        fInA = FloatArray(fIn.size) { fIn[it].alpha }
        pendingGlow = glowColors
        mRunning = true
        choreo.postFrameCallback(frameCb)
    }

    /** Ganti container yang tampil (compact / alert / panel) sambil morph. */
    private fun transition(v: View, w: Int, h: Int, r: Float, dur: Long, tintTo: Int, ease: Interpolator, glowColors: IntArray? = null) {
        val outs = listOf(compact, alertBox, panelBox).filter { it !== v && it.visibility == VISIBLE }
        val ins = ArrayList<View>()
        if (v.visibility != VISIBLE) {
            v.alpha = 0f
            v.visibility = VISIBLE
        }
        if (v.alpha < 1f || outs.isNotEmpty()) ins.add(v)
        shown = v
        if (glowColors == null) glow.hide()
        startMorph(w, h, r, dur, tintTo, ease, outs, ins, glowColors)
    }

    private fun notifyVisibility() {
        for (i in panels.indices) (panels[i] as? PanelLife)?.onVisible(state == S.PANEL && tab == i)
    }

    // ------------------------------------------------------------ compact

    private fun updateCompact() {
        val pr = Nusa.prefs
        val minimal = pr.minimal
        val musicOn = media.hasSession && media.playing
        val art = media.art
        val showArt = musicOn && art != null && !minimal
        val showPet = !minimal && pr.pet && !showArt
        pet.visibility = if (showPet) VISIBLE else GONE
        miniArt.visibility = if (showArt) VISIBLE else GONE
        if (showArt && lastMiniArt !== art) {
            lastMiniArt = art
            miniArt.setImageBitmap(art)
        }
        val showEq = musicOn && !minimal
        eq.visibility = if (showEq) VISIBLE else GONE
        eq.active = media.playing
    }

    private fun compactSize(): Pair<Int, Int> {
        compact.measure(MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED), MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED))
        val minimal = Nusa.prefs.minimal
        val bw = svc.dp(Nusa.prefs.notchW)
        val bh = svc.dp(Nusa.prefs.notchH)
        val minW = if (minimal) (bw * 0.75f).toInt() else bw
        val h = if (minimal) (bh * 0.8f).toInt() else bh
        return Pair(maxOf(minW, compact.measuredWidth + svc.dp(8)), h)
    }

    /** Menempel di tepi: sudut bawah agak kotak. Melayang: pil bulat penuh. */
    private fun compactR(h: Int): Float = if (flat) h * 0.42f else h / 2f

    private fun setCompactLp(w: Int, h: Int) {
        compact.layoutParams = LayoutParams(w, h, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
    }

    private fun fitCompact() {
        val (w, h) = compactSize()
        if (Math.abs(vW - w) > svc.dp(2) || Math.abs(vH - h) > 1f) {
            setCompactLp(w, h)
            startMorph(w, h, compactR(h), 220L, tint, easeInOut)
        }
    }

    fun showCompact() {
        state = S.COMPACT
        ui.removeCallbacks(endAlert)
        updateCompact()
        val (w, h) = compactSize()
        setCompactLp(w, h)
        transition(compact, w, h, compactR(h), 300L, C.BLACK, easeInOut)
        notifyVisibility()
    }

    // ------------------------------------------------------------ alerts

    fun enqueue(a: Alert) {
        pet.wiggle()
        when (state) {
            S.PANEL -> return
            S.ALERT -> if (queue.size < 4) queue.add(a)
            S.COMPACT -> showAlert(a)
        }
    }

    private fun showAlert(a: Alert) {
        state = S.ALERT
        current = a
        aTitle.text = a.title
        aSub.text = a.sub
        if (a.icon != null) {
            aImg.visibility = VISIBLE
            aImg.setImageDrawable(a.icon)
            aGlyph.visibility = GONE
            aIconBox.background = null
        } else {
            aImg.visibility = GONE
            aGlyph.visibility = VISIBLE
            aGlyph.text = a.glyph
            aIconBox.background = rounded(a.color, svc.dpf(20))
        }
        val w = minOf((screenW() * 0.9f).toInt(), svc.dp(400))
        alertBox.layoutParams = LayoutParams(w, svc.dp(ALERT_H), Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        transition(alertBox, w, svc.dp(ALERT_H), svc.dpf(30), 320L, C.BLACK, easeOut)
        notifyVisibility()
        ui.removeCallbacks(endAlert)
        ui.postDelayed(endAlert, a.ms)
    }

    // ------------------------------------------------------------ panel

    private fun panelW(): Int = minOf(screenW() - svc.dp(24), svc.dp(PANEL_W))

    private fun panelH(t: Int): Int = svc.dp(TAB_H[t])

    private fun styleTabs() {
        for (i in tabViews.indices) {
            val sel = i == tab
            tabViews[i].alpha = if (sel) 1f else 0.45f
            tabViews[i].background = if (sel) rounded(0x26FFFFFF, svc.dpf(100)) else null
        }
    }

    fun showPanel(t: Int) {
        ui.removeCallbacks(endAlert)
        queue.clear()
        current = null
        state = S.PANEL
        tab = t.coerceIn(0, panels.size - 1)
        Nusa.prefs.lastTab = tab
        val pw = panelW()
        panelBox.layoutParams = LayoutParams(pw, svc.dp(TAB_H.max()), Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        for (i in panels.indices) {
            panels[i].alpha = 1f
            panels[i].visibility = if (i == tab) VISIBLE else GONE
        }
        styleTabs()
        (panels[tab] as Refreshable).refresh()
        transition(panelBox, pw, panelH(tab), svc.dpf(28), 360L, wantedTint(), easeOut, tabGlow[tab])
        notifyVisibility()
    }

    private fun selectTab(t: Int) {
        if (t == tab) return
        val old = tab
        tab = t
        Nusa.prefs.lastTab = t
        styleTabs()
        val inV = panels[t]
        val outV = panels[old]
        for (i in panels.indices) {
            if (i != t && i != old) panels[i].visibility = GONE
        }
        (inV as Refreshable).refresh()
        inV.alpha = 0f
        inV.visibility = VISIBLE
        startMorph(panelW(), panelH(t), svc.dpf(28), 320L, wantedTint(), easeOut, listOf(outV), listOf(inV), tabGlow[t])
        notifyVisibility()
    }

    fun refreshData() {
        if (state == S.PANEL) (panels[tab] as Refreshable).refresh()
    }

    fun applySettings() {
        flat = Nusa.prefs.topOffset == 0
        box.invalidateOutline()
        if (state == S.COMPACT) showCompact()
    }

    // ------------------------------------------------------------ system hooks

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        super.onLayout(changed, l, t, r, b)
        box.invalidateOutline()
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.action == MotionEvent.ACTION_OUTSIDE) {
            if (state == S.PANEL) showCompact()
            return true
        }
        return super.dispatchTouchEvent(ev)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        post {
            when (state) {
                S.COMPACT -> showCompact()
                S.PANEL -> showPanel(tab)
                S.ALERT -> {
                }
            }
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        ui.post(uiTick)
    }

    override fun onDetachedFromWindow() {
        ui.removeCallbacks(uiTick)
        ui.removeCallbacks(endAlert)
        choreo.removeFrameCallback(frameCb)
        mRunning = false
        tintAnim?.cancel()
        Markets.stop()
        PrivSampler.stop()
        super.onDetachedFromWindow()
    }
}
