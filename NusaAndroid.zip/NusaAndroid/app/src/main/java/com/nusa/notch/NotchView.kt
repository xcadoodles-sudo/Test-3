package com.nusa.notch

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Notch yang menempel di tepi atas layar (atas datar, bawah melengkung).
 * COMPACT : pil kecil (maskot / album art + equalizer / timer)
 * ALERT   : melebar sebentar untuk notifikasi
 * PANEL   : ketuk pil -> player lebar (tab Music) atau panel lain; warna latar mengikuti album art
 */
@SuppressLint("ViewConstructor", "ClickableViewAccessibility")
class NotchView(private val svc: Context, private val media: MediaWatcher) : FrameLayout(svc) {
    enum class S { COMPACT, ALERT, PANEL }

    private val ui = Handler(Looper.getMainLooper())
    var state = S.COMPACT
        private set

    private val box = FrameLayout(svc)
    private val bg = GradientDrawable()
    private var curR = svc.dpf(17)
    private var tint = C.BLACK
    private var tintAnim: ValueAnimator? = null
    private var tintArt: Bitmap? = null
    private var tintCache = C.BLACK

    private val compact = LinearLayout(svc)
    private val alertBox = LinearLayout(svc)
    private val panelBox = LinearLayout(svc)

    // --- compact
    private val pet = PetView(svc)
    private val miniArt = ImageView(svc)
    private val gap = View(svc)
    private val cText = svc.tv("", 13f, C.TEXT, true)
    private val eq = EqView(svc)
    private var lastMiniArt: Bitmap? = null

    // --- alert
    private val aIconBox = FrameLayout(svc)
    private val aGlyph = svc.tv("", 18f, C.TEXT, true)
    private val aImg = ImageView(svc)
    private val aTitle = svc.tv("", 15f, C.TEXT, true)
    private val aSub = svc.tv("", 13f, 0x99FFFFFF.toInt())
    private var current: Alert? = null
    private val queue = java.util.ArrayDeque<Alert>()

    // --- panel
    private val tabsRow = LinearLayout(svc)
    private val body = FrameLayout(svc)
    private val music = MusicPanel(svc, media)
    private val timer = TimerPanel(svc)
    private val todo = TodoPanel(svc)
    private val water = WaterPanel(svc)
    private val shelf = ShelfPanel(svc)
    private val panels: List<View> = listOf(music, timer, todo, water, shelf)
    private val tabIcons = listOf("♪", "⏱", "✓", "💧", "📁")
    private val tabViews = ArrayList<TextView>()
    private var tab = 0

    private var anim: ValueAnimator? = null

    private val endAlert = Runnable {
        current = null
        val n = queue.poll()
        if (n != null) showAlert(n) else showCompact()
    }

    private val uiTick = object : Runnable {
        override fun run() {
            when (state) {
                S.COMPACT -> {
                    updateCompact()
                    fitCompact()
                }
                S.PANEL -> {
                    (panels[tab] as Refreshable).refresh()
                    animateTint(wantedTint())
                }
                S.ALERT -> {
                }
            }
            ui.postDelayed(this, 500)
        }
    }

    init {
        setTint(C.BLACK)
        applyR(svc.dpf(17))
        box.background = bg

        // ---------- compact
        compact.orientation = LinearLayout.HORIZONTAL
        compact.gravity = Gravity.CENTER_VERTICAL
        compact.setPadding(svc.dp(10), 0, svc.dp(10), 0)
        compact.addView(pet, LinearLayout.LayoutParams(svc.dp(22), svc.dp(22)))
        miniArt.scaleType = ImageView.ScaleType.CENTER_CROP
        miniArt.roundClip(svc.dpf(6))
        compact.addView(miniArt, LinearLayout.LayoutParams(svc.dp(22), svc.dp(22)))
        compact.addView(gap, LinearLayout.LayoutParams(svc.dp(34), 1))
        cText.minWidth = svc.dp(42)
        compact.addView(cText)
        compact.addView(eq, LinearLayout.LayoutParams(svc.dp(18), svc.dp(14)))
        compact.setOnClickListener {
            showPanel(if (media.hasSession && media.playing) 0 else Nusa.prefs.lastTab)
        }
        box.addView(compact, LayoutParams(WRAP, MATCH, Gravity.CENTER))

        // ---------- alert
        alertBox.orientation = LinearLayout.HORIZONTAL
        alertBox.gravity = Gravity.CENTER_VERTICAL
        alertBox.setPadding(svc.dp(14), 0, svc.dp(18), 0)
        aGlyph.gravity = Gravity.CENTER
        aIconBox.addView(aGlyph, LayoutParams(MATCH, MATCH))
        aImg.scaleType = ImageView.ScaleType.FIT_CENTER
        aImg.roundClip(svc.dpf(10))
        aIconBox.addView(aImg, LayoutParams(MATCH, MATCH))
        alertBox.addView(aIconBox, svc.llp(svc.dp(40), svc.dp(40)))
        val tcol = LinearLayout(svc)
        tcol.orientation = LinearLayout.VERTICAL
        aTitle.maxLines = 1
        aTitle.ellipsize = TextUtils.TruncateAt.END
        aSub.maxLines = 1
        aSub.ellipsize = TextUtils.TruncateAt.END
        tcol.addView(aTitle)
        tcol.addView(aSub, svc.llp(WRAP, WRAP, 0f, 0, 3, 0, 0))
        alertBox.addView(tcol, svc.llp(0, WRAP, 1f, 12, 0, 0, 0))
        alertBox.setOnClickListener {
            val a = current
            ui.removeCallbacks(endAlert)
            queue.clear()
            current = null
            a?.onClick?.invoke()
            if (a != null && a.tab >= 0) showPanel(a.tab) else showCompact()
        }
        alertBox.visibility = GONE
        box.addView(alertBox, LayoutParams(svc.dp(380), MATCH, Gravity.TOP or Gravity.CENTER_HORIZONTAL))

        // ---------- panel: strip ikon tab di atas, isi di bawah
        panelBox.orientation = LinearLayout.VERTICAL
        tabsRow.orientation = LinearLayout.HORIZONTAL
        tabsRow.gravity = Gravity.CENTER_VERTICAL
        tabsRow.setPadding(svc.dp(14), svc.dp(6), svc.dp(10), 0)
        for (i in tabIcons.indices) {
            val t = svc.tv(tabIcons[i], 16f, C.TEXT, true)
            t.gravity = Gravity.CENTER
            t.setPadding(svc.dp(6), svc.dp(6), svc.dp(6), svc.dp(6))
            t.setOnClickListener { selectTab(i) }
            tabViews.add(t)
            tabsRow.addView(t, svc.llp(0, svc.dp(30), 1f, 4, 0, 4, 0))
        }
        val close = svc.tv("⌃", 18f, 0x99FFFFFF.toInt(), true)
        close.setPadding(svc.dp(12), svc.dp(2), svc.dp(4), svc.dp(2))
        close.setOnClickListener { showCompact() }
        tabsRow.addView(close)
        panelBox.addView(tabsRow, svc.llp(MATCH, WRAP))
        body.setPadding(svc.dp(18), svc.dp(4), svc.dp(18), svc.dp(12))
        for (p in panels) body.addView(p, LayoutParams(MATCH, MATCH))
        panelBox.addView(body, svc.llp(MATCH, 0, 1f))
        panelBox.visibility = GONE
        box.addView(panelBox, LayoutParams(svc.dp(560), svc.dp(196), Gravity.TOP or Gravity.CENTER_HORIZONTAL))

        addView(box, LayoutParams(svc.dp(126), svc.dp(34), Gravity.TOP or Gravity.CENTER_HORIZONTAL))
        updateCompact()
        applyCompactSizeNow()
    }

    // ------------------------------------------------------------ util

    private fun screenW(): Int {
        return if (Build.VERSION.SDK_INT >= 30) {
            (svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager).currentWindowMetrics.bounds.width()
        } else {
            resources.displayMetrics.widthPixels
        }
    }

    /** Atas datar kalau menempel di tepi (offset 0), selain itu pil melayang bulat penuh. */
    private fun applyR(r: Float) {
        curR = r
        bg.cornerRadii = if (Nusa.prefs.topOffset == 0) {
            floatArrayOf(0f, 0f, 0f, 0f, r, r, r, r)
        } else {
            floatArrayOf(r, r, r, r, r, r, r, r)
        }
    }

    private fun setTint(c: Int) {
        tint = c
        val dark = Color.rgb((Color.red(c) * 0.5f).toInt(), (Color.green(c) * 0.5f).toInt(), (Color.blue(c) * 0.5f).toInt())
        bg.orientation = GradientDrawable.Orientation.LEFT_RIGHT
        bg.colors = intArrayOf(c, dark)
    }

    private fun tintFrom(art: Bitmap): Int {
        if (art === tintArt) return tintCache
        var out = C.BLACK
        try {
            val px = Bitmap.createScaledBitmap(art, 1, 1, true).getPixel(0, 0)
            val hsv = FloatArray(3)
            Color.colorToHSV(px, hsv)
            hsv[1] = (hsv[1] * 1.15f).coerceAtMost(0.85f)
            hsv[2] = 0.30f
            out = Color.HSVToColor(hsv)
        } catch (e: Exception) {
        }
        tintArt = art
        tintCache = out
        return out
    }

    private fun wantedTint(): Int {
        if (state == S.PANEL && tab == 0 && media.hasSession) {
            val art = media.art
            if (art != null) return tintFrom(art)
        }
        return C.BLACK
    }

    private fun animateTint(target: Int) {
        if (target == tint) return
        if (tintAnim?.isRunning == true) return
        val a = ValueAnimator.ofArgb(tint, target)
        a.duration = 350
        a.addUpdateListener { setTint(it.animatedValue as Int) }
        a.start()
        tintAnim = a
    }

    private fun animateTo(w: Int, h: Int, r: Float, dur: Long = 280L) {
        anim?.cancel()
        val lp = box.layoutParams
        val w0 = lp.width
        val h0 = lp.height
        val r0 = curR
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = dur
        a.interpolator = DecelerateInterpolator(1.8f)
        a.addUpdateListener {
            val f = it.animatedValue as Float
            lp.width = (w0 + (w - w0) * f).toInt()
            lp.height = (h0 + (h - h0) * f).toInt()
            applyR(r0 + (r - r0) * f)
            box.layoutParams = lp
        }
        a.start()
        anim = a
    }

    private fun show(v: View) {
        for (x in listOf(compact, alertBox, panelBox)) {
            x.animate().cancel()
            if (x === v) {
                x.alpha = 0f
                x.visibility = VISIBLE
                x.animate().alpha(1f).setDuration(220).setStartDelay(60).start()
            } else {
                x.visibility = GONE
            }
        }
    }

    // ------------------------------------------------------------ compact

    private fun updateCompact() {
        val pr = Nusa.prefs
        val minimal = pr.minimal
        val musicOn = media.hasSession && media.playing
        val art = media.art
        val showArt = musicOn && art != null && !minimal
        val showPet = !minimal && pr.pet && !showArt
        val timerOn = Nusa.pomo.running
        pet.visibility = if (showPet) VISIBLE else GONE
        miniArt.visibility = if (showArt) VISIBLE else GONE
        if (showArt && lastMiniArt !== art) {
            lastMiniArt = art
            miniArt.setImageBitmap(art)
        }
        cText.visibility = if (timerOn) VISIBLE else GONE
        if (timerOn) cText.text = fmtCountdown(Nusa.pomo.left())
        val showEq = musicOn && !minimal
        eq.visibility = if (showEq) VISIBLE else GONE
        eq.active = media.playing
        gap.visibility = if ((showArt || showPet) && (timerOn || showEq)) VISIBLE else GONE
    }

    private fun compactSize(): Pair<Int, Int> {
        compact.measure(MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED), MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED))
        val minimal = Nusa.prefs.minimal
        val minW = if (minimal) svc.dp(84) else svc.dp(126)
        val h = if (minimal) svc.dp(24) else svc.dp(34)
        return Pair(maxOf(minW, compact.measuredWidth + svc.dp(8)), h)
    }

    private fun applyCompactSizeNow() {
        val (w, h) = compactSize()
        val lp = box.layoutParams
        lp.width = w
        lp.height = h
        applyR(h / 2f)
        box.layoutParams = lp
    }

    private fun fitCompact() {
        if (anim?.isRunning == true) return
        val (w, h) = compactSize()
        val lp = box.layoutParams
        if (Math.abs(lp.width - w) > svc.dp(2) || lp.height != h) animateTo(w, h, h / 2f, 180L)
    }

    fun showCompact() {
        state = S.COMPACT
        ui.removeCallbacks(endAlert)
        updateCompact()
        show(compact)
        animateTint(C.BLACK)
        val (w, h) = compactSize()
        animateTo(w, h, h / 2f)
    }

    // ------------------------------------------------------------ alerts

    fun enqueue(a: Alert) {
        pet.wiggle()
        when (state) {
            S.PANEL -> return
            S.ALERT -> if (queue.size < 4) queue.add(a)
            S.COMPACT -> showAlert(a)
        }
    }

    private fun showAlert(a: Alert) {
        state = S.ALERT
        current = a
        aTitle.text = a.title
        aSub.text = a.sub
        if (a.icon != null) {
            aImg.visibility = VISIBLE
            aImg.setImageDrawable(a.icon)
            aGlyph.visibility = GONE
            aIconBox.background = null
        } else {
            aImg.visibility = GONE
            aGlyph.visibility = VISIBLE
            aGlyph.text = a.glyph
            aIconBox.background = rounded(a.color, svc.dpf(20))
        }
        val w = minOf((screenW() * 0.9f).toInt(), svc.dp(400))
        val lp = alertBox.layoutParams
        lp.width = w
        alertBox.layoutParams = lp
        show(alertBox)
        animateTint(C.BLACK)
        animateTo(w, svc.dp(68), svc.dpf(30))
        ui.removeCallbacks(endAlert)
        ui.postDelayed(endAlert, a.ms)
    }

    // ------------------------------------------------------------ panel

    private fun panelW(t: Int): Int = minOf(screenW() - svc.dp(24), if (t == 0) svc.dp(560) else svc.dp(620))

    private fun panelH(t: Int): Int = if (t == 0) svc.dp(196) else svc.dp(290)

    private fun sizePanel(t: Int) {
        val w = panelW(t)
        val h = panelH(t)
        val lp = panelBox.layoutParams
        lp.width = w
        lp.height = h
        panelBox.layoutParams = lp
        animateTo(w, h, svc.dpf(28))
    }

    fun showPanel(t: Int) {
        ui.removeCallbacks(endAlert)
        queue.clear()
        current = null
        state = S.PANEL
        show(panelBox)
        selectTab(t)
    }

    private fun selectTab(t: Int) {
        tab = t
        Nusa.prefs.lastTab = t
        for (i in panels.indices) panels[i].visibility = if (i == t) VISIBLE else GONE
        for (i in tabViews.indices) {
            val sel = i == t
            tabViews[i].alpha = if (sel) 1f else 0.45f
            tabViews[i].background = if (sel) rounded(0x26FFFFFF, svc.dpf(100)) else null
        }
        (panels[t] as Refreshable).refresh()
        animateTint(wantedTint())
        if (state == S.PANEL) sizePanel(t)
    }

    fun refreshData() {
        if (state == S.PANEL) (panels[tab] as Refreshable).refresh()
    }

    fun applySettings() {
        applyR(curR)
        if (state == S.COMPACT) showCompact()
    }

    // ------------------------------------------------------------ system hooks

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.action == MotionEvent.ACTION_OUTSIDE) {
            if (state == S.PANEL) showCompact()
            return true
        }
        return super.dispatchTouchEvent(ev)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        post {
            when (state) {
                S.COMPACT -> showCompact()
                S.PANEL -> showPanel(tab)
                S.ALERT -> {
                }
            }
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        ui.post(uiTick)
    }

    override fun onDetachedFromWindow() {
        ui.removeCallbacks(uiTick)
        ui.removeCallbacks(endAlert)
        anim?.cancel()
        tintAnim?.cancel()
        super.onDetachedFromWindow()
    }
}
