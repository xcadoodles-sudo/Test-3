package com.nusa.notch

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.provider.Settings
import android.text.TextUtils
import android.view.DragEvent
import android.view.Gravity
import android.view.View
import android.webkit.MimeTypeMap
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File

// ------------------------------------------------------------------ MUSIC

class MusicPanel(private val c: Context, private val m: MediaWatcher) : FrameLayout(c), Refreshable {
    private val art = ImageView(c)
    private val tTitle = c.tv("", 15f, C.TEXT, true)
    private val tArtist = c.tv("", 12f, 0x99FFFFFF.toInt())
    private val l0 = c.tv("", 14f, C.TEXT, true)
    private val l1 = c.tv("", 13f, 0x80FFFFFF.toInt())
    private val l2 = c.tv("", 13f, 0x44FFFFFF.toInt())
    private val lyricCol = LinearLayout(c)
    private val bar = ProgressLine(c)
    private val tCur = c.tv("0:00", 11f, 0xB3FFFFFF.toInt(), true)
    private val tRem = c.tv("-0:00", 11f, 0xB3FFFFFF.toInt(), true)
    private val bPlay = ImageView(c)
    private val bLyr: TextView
    private val content = LinearLayout(c)
    private val empty = LinearLayout(c)
    private val emptyTxt = c.tv("", 15f, C.SUB)
    private val emptyBtn: TextView
    private var lastArt: Bitmap? = null
    private var lastPlaying: Boolean? = null

    private fun ctrl(res: Int, onClick: () -> Unit): ImageView {
        val iv = ImageView(c)
        iv.setImageResource(res)
        iv.setColorFilter(C.TEXT)
        iv.setPadding(c.dp(10), c.dp(8), c.dp(10), c.dp(8))
        iv.setOnClickListener { onClick() }
        return iv
    }

    init {
        content.orientation = LinearLayout.VERTICAL

        // baris 1: art | judul + artis | lirik 3 baris
        val r1 = LinearLayout(c)
        r1.gravity = Gravity.CENTER_VERTICAL
        art.scaleType = ImageView.ScaleType.CENTER_CROP
        art.background = rounded(0x33FFFFFF, c.dpf(12))
        art.roundClip(c.dpf(12))
        r1.addView(art, c.llp(c.dp(56), c.dp(56)))
        val info = LinearLayout(c)
        info.orientation = LinearLayout.VERTICAL
        info.gravity = Gravity.CENTER_VERTICAL
        tTitle.maxLines = 1
        tTitle.ellipsize = TextUtils.TruncateAt.END
        tArtist.maxLines = 1
        tArtist.ellipsize = TextUtils.TruncateAt.END
        info.addView(tTitle)
        info.addView(tArtist, c.llp(WRAP, WRAP, 0f, 0, 3, 0, 0))
        r1.addView(info, c.llp(0, WRAP, 1f, 12, 0, 12, 0))
        lyricCol.orientation = LinearLayout.VERTICAL
        lyricCol.gravity = Gravity.CENTER_VERTICAL
        for (t in listOf(l0, l1, l2)) {
            t.maxLines = 1
            t.ellipsize = TextUtils.TruncateAt.END
            lyricCol.addView(t, c.llp(MATCH, WRAP, 0f, 0, 1, 0, 1))
        }
        r1.addView(lyricCol, c.llp(0, WRAP, 1.25f))
        content.addView(r1, c.llp(MATCH, 0, 1f))

        // baris 2: waktu berjalan | progress | sisa waktu
        val r2 = LinearLayout(c)
        r2.gravity = Gravity.CENTER_VERTICAL
        tCur.minWidth = c.dp(34)
        tRem.minWidth = c.dp(38)
        tRem.gravity = Gravity.END
        bar.fillColor = C.TEXT
        bar.onSeek = { f -> m.seekFrac(f) }
        r2.addView(tCur)
        r2.addView(bar, c.llp(0, c.dp(14), 1f, 8, 0, 8, 0))
        r2.addView(tRem)
        content.addView(r2, c.llp(MATCH, WRAP, 0f, 0, 6, 0, 0))

        // baris 3: tombol
        val r3 = LinearLayout(c)
        r3.gravity = Gravity.CENTER
        bLyr = c.tv("💬", 18f)
        bLyr.gravity = Gravity.CENTER
        bLyr.setOnClickListener {
            Nusa.prefs.showLyrics = !Nusa.prefs.showLyrics
            refresh()
        }
        r3.addView(bLyr, c.llp(c.dp(48), c.dp(40)))
        r3.addView(ctrl(android.R.drawable.ic_media_rew) { m.prev() }, c.llp(c.dp(52), c.dp(40)))
        bPlay.setImageResource(android.R.drawable.ic_media_play)
        bPlay.setColorFilter(C.TEXT)
        bPlay.setPadding(c.dp(10), c.dp(6), c.dp(10), c.dp(6))
        bPlay.setOnClickListener { m.toggle() }
        r3.addView(bPlay, c.llp(c.dp(60), c.dp(40)))
        r3.addView(ctrl(android.R.drawable.ic_media_ff) { m.next() }, c.llp(c.dp(52), c.dp(40)))
        r3.addView(View(c), c.llp(c.dp(48), 1))
        content.addView(r3, c.llp(MATCH, WRAP, 0f, 0, 2, 0, 0))
        addView(content, LayoutParams(MATCH, MATCH))

        // keadaan kosong
        empty.orientation = LinearLayout.VERTICAL
        empty.gravity = Gravity.CENTER
        emptyTxt.gravity = Gravity.CENTER
        empty.addView(emptyTxt)
        emptyBtn = c.pill("Open settings", C.ACCENT) {
            val i = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try {
                c.startActivity(i)
            } catch (e: Exception) {
            }
        }
        empty.addView(emptyBtn, c.llp(WRAP, WRAP, 0f, 0, 12, 0, 0))
        addView(empty, LayoutParams(MATCH, MATCH))
    }

    override fun refresh() {
        m.ensure()
        val has = m.hasSession && (m.title.isNotBlank() || m.artist.isNotBlank())
        content.visibility = if (has) VISIBLE else GONE
        empty.visibility = if (has) GONE else VISIBLE
        if (!has) {
            emptyTxt.text = if (!m.granted) "Allow notification access\nto see and control your music" else "Nothing playing"
            emptyBtn.visibility = if (!m.granted) VISIBLE else GONE
            return
        }
        tTitle.text = m.title
        tArtist.text = m.artist
        val showL = Nusa.prefs.showLyrics
        lyricCol.visibility = if (showL) VISIBLE else GONE
        bLyr.alpha = if (showL) 1f else 0.4f
        if (showL) {
            val w = m.lyricWindow()
            l0.text = w[0]
            l1.text = w[1]
            l2.text = w[2]
        }
        if (lastArt !== m.art) {
            lastArt = m.art
            art.setImageBitmap(m.art)
        }
        if (lastPlaying != m.playing) {
            lastPlaying = m.playing
            bPlay.setImageResource(if (m.playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play)
        }
        val pos = m.position()
        tCur.text = fmtTime(pos)
        tRem.text = if (m.duration > 0) "-" + fmtTime(m.duration - pos) else "--:--"
        bar.frac = if (m.duration > 0) pos.toFloat() / m.duration else 0f
    }
}

// ------------------------------------------------------------------ SHELF

class ShelfPanel(private val c: Context) : FrameLayout(c), Refreshable {
    private val hint = c.tv("Drop files here · Drag out anytime", 13f, C.SUB)
    private val row = LinearLayout(c)
    private val frame = FrameLayout(c)
    // null = tampilan harus dibangun ulang. Jangan pakai "" karena shelf kosong juga bersignature "",
    // sehingga refresh() akan return lebih awal dan chip lama tetap tampil setelah Clear / ✕.
    private var sig: String? = null
    private var confirmClear = false
    private val bClear: TextView

    init {
        val col = LinearLayout(c)
        col.orientation = LinearLayout.VERTICAL
        val head = LinearLayout(c)
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(c.tv("📁 File Shelf", 17f, C.TEXT, true))
        head.addView(View(c), c.llp(0, 1, 1f))
        head.addView(c.pill("+ Add", C.ACCENT, C.TEXT, 12f) {
            val i = Intent(c, ShareReceiverActivity::class.java)
            i.action = "com.nusa.notch.PICK"
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            c.startActivity(i)
        }, c.llp(WRAP, WRAP, 0f, 0, 0, 6, 0))
        bClear = c.pill("Clear", C.CARD2, C.RED, 12f) {
            if (!confirmClear) {
                confirmClear = true
                postDelayed({
                    confirmClear = false
                    bClear.text = "Clear"
                }, 3000)
                bClear.text = "Sure?"
            } else {
                confirmClear = false
                bClear.text = "Clear"
                Nusa.shelf.clear()
                sig = null
                refresh()
            }
        }
        head.addView(bClear)
        col.addView(head, c.llp(MATCH, WRAP, 0f, 0, 0, 0, 6))
        col.addView(hint, c.llp(WRAP, WRAP, 0f, 0, 0, 0, 8))
        val hs = HorizontalScrollView(c)
        hs.isHorizontalScrollBarEnabled = false
        row.orientation = LinearLayout.HORIZONTAL
        hs.addView(row, LayoutParams(WRAP, MATCH))
        frame.background = rounded(C.CARD, c.dpf(18))
        frame.setPadding(c.dp(10), c.dp(10), c.dp(10), c.dp(10))
        frame.addView(hs, LayoutParams(MATCH, MATCH))
        col.addView(frame, c.llp(MATCH, 0, 1f))
        addView(col, LayoutParams(MATCH, MATCH))
        setOnDragListener { _, e -> onDrag(e) }
    }

    private fun onDrag(e: DragEvent): Boolean {
        when (e.action) {
            DragEvent.ACTION_DRAG_STARTED -> return true
            DragEvent.ACTION_DRAG_ENTERED -> {
                hint.text = "Release to add"
                frame.background = rounded(C.CARD2, c.dpf(18))
            }
            DragEvent.ACTION_DRAG_EXITED, DragEvent.ACTION_DRAG_ENDED -> {
                hint.text = "Drop files here · Drag out anytime"
                frame.background = rounded(C.CARD, c.dpf(18))
            }
            DragEvent.ACTION_DROP -> {
                handleDrop(e)
                hint.text = "Drop files here · Drag out anytime"
                frame.background = rounded(C.CARD, c.dpf(18))
            }
        }
        return true
    }

    private fun handleDrop(e: DragEvent) {
        val clip = e.clipData ?: return
        var fail = 0
        for (i in 0 until clip.itemCount) {
            val item = clip.getItemAt(i)
            val uri = item.uri
            val txt = item.text?.toString()
            if (uri != null) {
                val sch = uri.scheme ?: ""
                if (sch == "http" || sch == "https") Nusa.shelf.addLink(uri.toString())
                else if (!Nusa.shelf.addUri(uri)) fail++
            } else if (txt != null && (txt.startsWith("http://") || txt.startsWith("https://"))) {
                Nusa.shelf.addLink(txt.trim())
            }
        }
        sig = null
        refresh()
        if (fail > 0) {
            Bus.alert(Alert("Couldn't read that file", "Use Share → Nusa Shelf, or drop it inside the Nusa app", "!", C.RED, tab = 4))
        }
    }

    private fun emoji(f: File): String {
        if (Nusa.shelf.isLink(f)) return "🔗"
        return when (f.extension.lowercase()) {
            "png", "jpg", "jpeg", "gif", "webp", "heic", "bmp" -> "🖼"
            "mp4", "mkv", "mov", "webm", "avi" -> "🎞"
            "mp3", "flac", "wav", "m4a", "ogg", "aac" -> "🎵"
            "pdf" -> "📕"
            "doc", "docx", "txt", "md", "rtf" -> "📄"
            "xls", "xlsx", "csv" -> "📊"
            "ppt", "pptx" -> "📽"
            "zip", "rar", "7z", "tar", "gz" -> "🗜"
            "apk" -> "📦"
            else -> "📄"
        }
    }

    private fun open(f: File) {
        try {
            val i: Intent
            if (Nusa.shelf.isLink(f)) {
                val u = Nusa.shelf.linkTarget(f) ?: return
                i = Intent(Intent.ACTION_VIEW, Uri.parse(u))
            } else {
                val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "*/*"
                i = Intent(Intent.ACTION_VIEW)
                i.setDataAndType(Nusa.shelf.uriFor(f), mime)
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            c.startActivity(i)
        } catch (e: Exception) {
            Bus.alert(Alert("No app can open this", f.name, "!", C.ORANGE))
        }
    }

    private fun startDrag(v: View, f: File) {
        try {
            val clip: ClipData
            if (Nusa.shelf.isLink(f)) {
                clip = ClipData.newPlainText("link", Nusa.shelf.linkTarget(f) ?: "")
            } else {
                clip = ClipData.newUri(c.contentResolver, f.name, Nusa.shelf.uriFor(f))
            }
            val flags = View.DRAG_FLAG_GLOBAL or View.DRAG_FLAG_GLOBAL_URI_READ
            v.startDragAndDrop(clip, View.DragShadowBuilder(v), null, flags)
        } catch (e: Exception) {
        }
    }

    override fun refresh() {
        val items = Nusa.shelf.items()
        val s = items.joinToString("|") { it.name + it.lastModified() }
        if (s == sig) return
        sig = s
        row.removeAllViews()
        if (items.isEmpty()) {
            val e = c.tv("Shelf is empty", 14f, C.SUB)
            row.addView(e, c.llp(WRAP, WRAP, 0f, 6, 6, 0, 0))
            return
        }
        for (f in items) {
            val chip = FrameLayout(c)
            chip.background = rounded(C.CARD2, c.dpf(14))
            val col = LinearLayout(c)
            col.orientation = LinearLayout.VERTICAL
            col.gravity = Gravity.CENTER_HORIZONTAL
            col.setPadding(c.dp(8), c.dp(10), c.dp(8), c.dp(8))
            col.addView(c.tv(emoji(f), 30f))
            val n = c.tv(f.name, 11f, C.TEXT)
            n.maxLines = 2
            n.gravity = Gravity.CENTER
            n.ellipsize = TextUtils.TruncateAt.MIDDLE
            col.addView(n, c.llp(c.dp(84), WRAP, 0f, 0, 6, 0, 0))
            chip.addView(col, LayoutParams(WRAP, WRAP))
            val x = c.tv("✕", 12f, C.SUB)
            x.setPadding(c.dp(8), c.dp(4), c.dp(8), c.dp(4))
            x.setOnClickListener {
                Nusa.shelf.remove(f)
                sig = null
                refresh()
            }
            val xl = LayoutParams(WRAP, WRAP)
            xl.gravity = Gravity.TOP or Gravity.END
            chip.addView(x, xl)
            chip.setOnClickListener { open(f) }
            chip.setOnLongClickListener {
                startDrag(chip, f)
                true
            }
            row.addView(chip, c.llp(WRAP, WRAP, 0f, 0, 0, 8, 0))
        }
    }
}
