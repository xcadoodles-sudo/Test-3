package com.nusa.notch

import android.content.pm.PackageManager
import android.os.SystemClock
import rikka.shizuku.Shizuku
import kotlin.concurrent.thread

/** Akses shell (uid 2000) lewat Shizuku. Semua fungsi aman dipanggil walau Shizuku tidak terpasang. */
object Priv {
    fun running(): Boolean = try {
        Shizuku.pingBinder()
    } catch (e: Throwable) {
        false
    }

    fun granted(): Boolean = try {
        running() && !Shizuku.isPreV11() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) {
        false
    }

    fun request(code: Int) {
        try {
            Shizuku.requestPermission(code)
        } catch (e: Throwable) {
        }
    }

    /** Blocking. Jalankan satu perintah `sh -c` sebagai shell; null kalau gagal. */
    fun run(cmd: String): String? {
        return try {
            val m = Shizuku::class.java.getDeclaredMethod(
                "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
            )
            m.isAccessible = true
            val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
            val out = p.inputStream.bufferedReader().readText()
            p.waitFor()
            out
        } catch (e: Throwable) {
            null
        }
    }
}

class PrivData(val cpu: Float, val gpu: Float, val cpuT: Float, val gpuT: Float, val at: Long)

/** Polling hardware lewat Shizuku di background, hanya selama tab Device terbuka. */
object PrivSampler {
    @Volatile var data: PrivData? = null
    @Volatile private var active = false
    private var th: Thread? = null
    private var pTotal = 0L
    private var pIdle = 0L

    private const val CMD = "head -n1 /proc/stat; echo '#G'; cat /sys/class/kgsl/kgsl-3d0/gpu_busy_percentage 2>/dev/null; " +
        "echo '#G2'; cat /sys/class/kgsl/kgsl-3d0/gpubusy 2>/dev/null; echo '#M'; cat /sys/kernel/gpu/gpu_busy 2>/dev/null; " +
        "echo '#T'; for z in /sys/class/thermal/thermal_zone*; do echo \"\$(cat \$z/type 2>/dev/null) \$(cat \$z/temp 2>/dev/null)\"; done"

    fun start() {
        if (active) return
        active = true
        th = thread(name = "nusa-priv") {
            while (active) {
                if (Priv.granted()) {
                    val out = Priv.run(CMD)
                    if (out != null) parse(out)
                } else {
                    data = null
                }
                try {
                    Thread.sleep(1500)
                } catch (e: InterruptedException) {
                }
            }
        }
    }

    fun stop() {
        active = false
        th?.interrupt()
        th = null
    }

    private fun nums(s: String): List<Double> = Regex("[0-9.]+").findAll(s).mapNotNull { it.value.toDoubleOrNull() }.toList()

    private fun parse(out: String) {
        var cpu = -1f
        var gpu = -1f
        var section = ""
        val cT = ArrayList<Double>()
        val gT = ArrayList<Double>()
        for (line in out.lines()) {
            val l = line.trim()
            if (l.isEmpty()) continue
            if (l.startsWith("cpu ")) {
                val p = l.split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
                if (p.size >= 5) {
                    val idle = p[3] + p[4]
                    val total = p.sum()
                    val dT = total - pTotal
                    val dI = idle - pIdle
                    if (pTotal != 0L && dT > 0) cpu = ((dT - dI).toFloat() / dT * 100f).coerceIn(0f, 100f)
                    pTotal = total
                    pIdle = idle
                }
                continue
            }
            if (l.startsWith("#")) {
                section = l
                continue
            }
            when (section) {
                "#G" -> if (gpu < 0f) nums(l).firstOrNull()?.let { gpu = it.toFloat().coerceIn(0f, 100f) }
                "#G2" -> if (gpu < 0f) {
                    val n = nums(l)
                    if (n.size >= 2 && n[1] > 0) gpu = (n[0] / n[1] * 100).toFloat().coerceIn(0f, 100f)
                }
                "#M" -> if (gpu < 0f) nums(l).firstOrNull()?.let { gpu = it.toFloat().coerceIn(0f, 100f) }
                "#T" -> {
                    val parts = l.split(" ")
                    if (parts.size >= 2) {
                        var v = parts.last().toDoubleOrNull() ?: continue
                        if (v > 1000) v /= 1000.0
                        if (v < 10 || v > 130) continue
                        val t = parts[0].lowercase()
                        if (t.startsWith("gpu") || t.contains("kgsl") || t.contains("mali")) gT.add(v)
                        else if (t.startsWith("cpu") || t.contains("mtktscpu") || t.contains("soc_thermal") || t.startsWith("big") || t.startsWith("little")) cT.add(v)
                    }
                }
            }
        }
        data = PrivData(
            cpu, gpu,
            if (cT.isEmpty()) Float.NaN else cT.max().toFloat(),
            if (gT.isEmpty()) Float.NaN else gT.max().toFloat(),
            SystemClock.elapsedRealtime()
        )
    }
}
