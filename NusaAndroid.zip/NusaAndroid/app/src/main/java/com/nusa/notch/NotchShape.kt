package com.nusa.notch

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.view.Choreographer
import android.view.View
import android.view.ViewOutlineProvider
import android.view.animation.Interpolator
import android.widget.FrameLayout

/**
 * Pegas teredam kritis (tanpa overshoot): mulai halus, cepat di tengah, mendarat lembut.
 * w makin besar = makin cepat mendarat.
 */
class Spring(private val w: Float) : Interpolator {
    private val norm = 1f - (1f + w) * Math.exp(-w.toDouble()).toFloat()

    override fun getInterpolation(t: Float): Float {
        val x = t.coerceIn(0f, 1f)
        return (1f - (1f + w * x) * Math.exp((-w * x).toDouble()).toFloat()) / norm
    }
}

/**
 * Bentuk notch. Dua lapis:
 *  - lapisan bawah menggambar siluet penuh (termasuk "telinga" cekung di sudut atas, seperti
 *    notch MacBook) dengan gradasi warna;
 *  - lapisan [content] di atasnya, di-clip ke badan notch (tanpa telinga), tempat semua isi ditaruh.
 *
 * Bentuk (lebar, tinggi, radius) dianimasikan lewat [animate]. Selama animasi tidak ada layout
 * ulang dan tidak ada perubahan ukuran jendela: yang berubah cuma outline dan siluet.
 */
class NotchShape(c: Context) : FrameLayout(c) {
    val content = FrameLayout(c)

    var vW = 0f
        private set
    var vH = 0f
        private set
    var vR = 0f
        private set
    var tint = C.BLACK
        private set

    /** Menempel di tepi atas layar (atas datar + telinga). false = pil melayang. */
    var flat = true

    /** Radius telinga (px). 0 = tanpa telinga. */
    var ear = 0f

    private val bgView = object : View(c) {
        override fun onDraw(canvas: Canvas) {
            drawShape(canvas)
        }
    }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val arc = RectF()
    private val gm = Matrix()
    private var shader: LinearGradient? = null

    private val choreo = Choreographer.getInstance()
    private val argb = ArgbEvaluator()
    private var running = false
    private var dur = 1f
    private var el = 0f
    private var last = 0L
    private var w0 = 0f
    private var h0 = 0f
    private var r0 = 0f
    private var w1 = 0f
    private var h1 = 0f
    private var r1 = 0f
    private var t0 = 0
    private var t1 = 0
    private var eW: Interpolator = Spring(9f)
    private var eH: Interpolator = Spring(10f)
    private var onProg: ((Float) -> Unit)? = null
    private var onDone: (() -> Unit)? = null
    private var tintAnim: ValueAnimator? = null

    val animating: Boolean get() = running

    init {
        addView(bgView, LayoutParams(MATCH, MATCH))
        addView(content, LayoutParams(MATCH, MATCH))
        content.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                val cx = view.width / 2f
                val l = Math.round(cx - vW / 2f)
                val r = Math.round(cx + vW / 2f)
                val top = if (flat) -Math.round(vR) - 2 else 0
                outline.setRoundRect(l, top, r, Math.round(vH), vR)
            }
        }
        content.clipToOutline = true
        buildShader(C.BLACK)
    }

    // ------------------------------------------------------------ warna

    private fun buildShader(col: Int) {
        val dark = Color.rgb((Color.red(col) * 0.5f).toInt(), (Color.green(col) * 0.5f).toInt(), (Color.blue(col) * 0.5f).toInt())
        shader = LinearGradient(0f, 0f, 1f, 0f, col, dark, Shader.TileMode.CLAMP)
        paint.shader = shader
    }

    fun setTintNow(col: Int) {
        tint = col
        buildShader(col)
        bgView.invalidate()
    }

    /** Pindah warna halus (dipakai saat warna album berubah). Diabaikan selagi bentuk beranimasi. */
    fun animateTint(target: Int) {
        if (target == tint || running) return
        if (tintAnim?.isRunning == true) return
        val a = ValueAnimator.ofArgb(tint, target)
        a.duration = 350
        a.addUpdateListener { setTintNow(it.animatedValue as Int) }
        a.start()
        tintAnim = a
    }

    // ------------------------------------------------------------ gambar

    private fun drawShape(cv: Canvas) {
        if (vW <= 0f || vH <= 0f) return
        val cx = width / 2f
        val l = cx - vW / 2f
        val r = cx + vW / 2f
        val br = minOf(vR, vH / 2f, vW / 2f)
        path.reset()
        if (flat && ear > 0.5f) {
            val e = minOf(ear, vH - br)
            path.moveTo(l - e, 0f)
            path.lineTo(r + e, 0f)
            // telinga kanan: lengkung cekung dari tepi atas turun ke sisi badan
            arc.set(r, 0f, r + 2f * e, 2f * e)
            path.arcTo(arc, 270f, -90f)
            path.lineTo(r, vH - br)
            arc.set(r - 2f * br, vH - 2f * br, r, vH)
            path.arcTo(arc, 0f, 90f)
            path.lineTo(l + br, vH)
            arc.set(l, vH - 2f * br, l + 2f * br, vH)
            path.arcTo(arc, 90f, 90f)
            path.lineTo(l, e)
            // telinga kiri
            arc.set(l - 2f * e, 0f, l, 2f * e)
            path.arcTo(arc, 0f, -90f)
            path.close()
        } else {
            val top = if (flat) -br - 2f else 0f
            path.addRoundRect(l, top, r, vH, br, br, Path.Direction.CW)
        }
        gm.setScale(vW, 1f)
        gm.postTranslate(l, 0f)
        shader?.setLocalMatrix(gm)
        cv.drawPath(path, paint)
    }

    private fun touch() {
        content.invalidateOutline()
        bgView.invalidate()
    }

    // ------------------------------------------------------------ animasi

    fun setShapeNow(w: Float, h: Float, r: Float) {
        stopAnim()
        vW = w
        vH = h
        vR = r
        touch()
    }

    private fun stopAnim() {
        if (running) {
            choreo.removeFrameCallback(frameCb)
            running = false
        }
        onProg = null
        onDone = null
    }

    fun release() {
        stopAnim()
        tintAnim?.cancel()
    }

    /**
     * Morph ke bentuk baru mulai dari bentuk yang tampil sekarang (aman dipanggil ulang di tengah
     * animasi). [onProgress] menerima kemajuan 0..1 yang sudah di-ease; [onEnd] dipanggil sekali
     * di akhir (tidak dipanggil kalau animasi diganti animasi lain).
     */
    fun animate(
        w: Float, h: Float, r: Float, tintTo: Int, durMs: Long, omega: Float,
        onProgress: ((Float) -> Unit)? = null, onEnd: (() -> Unit)? = null
    ) {
        if (running) {
            choreo.removeFrameCallback(frameCb)
            running = false
        }
        tintAnim?.cancel()
        w0 = vW
        h0 = vH
        r0 = vR
        w1 = w
        h1 = h
        r1 = r
        t0 = tint
        t1 = tintTo
        eW = Spring(omega)
        eH = Spring(omega * 1.18f)
        dur = durMs.toFloat()
        el = 0f
        last = 0L
        onProg = onProgress
        onDone = onEnd
        running = true
        choreo.postFrameCallback(frameCb)
    }

    private val frameCb = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!running) return
            if (last == 0L) {
                last = frameTimeNanos
            } else {
                // dt dibatasi supaya frame tersendat tidak bikin animasi melompat
                el += ((frameTimeNanos - last) / 1_000_000f).coerceIn(0f, 32f)
                last = frameTimeNanos
            }
            val u = (el / dur).coerceAtMost(1f)
            val f = eW.getInterpolation(u)
            val fh = eH.getInterpolation(u)
            vW = w0 + (w1 - w0) * f
            vH = h0 + (h1 - h0) * fh
            vR = r0 + (r1 - r0) * f
            if (t1 != t0) {
                tint = argb.evaluate(f, t0, t1) as Int
                buildShader(tint)
            }
            touch()
            onProg?.invoke(f)
            if (u >= 1f) {
                running = false
                vW = w1
                vH = h1
                vR = r1
                if (t1 != t0) {
                    tint = t1
                    buildShader(t1)
                }
                touch()
                val d = onDone
                onDone = null
                onProg = null
                d?.invoke()
            } else {
                choreo.postFrameCallback(this)
            }
        }
    }

    override fun onDetachedFromWindow() {
        stopAnim()
        tintAnim?.cancel()
        super.onDetachedFromWindow()
    }
}
