# Nusa untuk Android (port dari NusaSetup.exe)

"Living notch" yang melayang di tengah-atas layar, versi Android untuk Xiaomi Pad 6S Pro.
Kotlin murni, tanpa Compose, dependensi cuma `androidx.core`.

## Cara build (Android Studio)
1. Buka folder `NusaAndroid` di Android Studio (Ladybug atau lebih baru). Tunggu Gradle sync (butuh internet sekali).
2. Colok tablet (USB debugging aktif) lalu Run, atau Build > Build APK(s) dan install `app-debug.apk`.
3. Buka app Nusa, lalu beri izin dari atas ke bawah:
   - Display over other apps (wajib)
   - Notification access (musik, lirik, notif app)
   - Post notifications, Bluetooth devices
   - Battery: No restrictions, lalu tombol Xiaomi autostart (HyperOS suka mematikan service)
4. Tekan **Start notch**.

## Fitur
| Tab | Isi |
|---|---|
| ♪ Music | MediaSessionManager + prev/play/next, seek, lirik LRCLIB sinkron per baris |
| 📱 Device | CPU, GPU, memory, suhu CPU/GPU, baterai (minimalis, 4 kartu) |
| 📈 Markets | Watchlist ala TradingView + chart (1D/5D/1M), harga hampir realtime. Default BTCUSD, XAUUSD, dll; tombol ＋ untuk tambah pair, tekan-lama untuk hapus |
| 📅 Calendar | Kalender bulanan + cuaca (Open-Meteo, tanpa API key) + prakiraan 3 hari |
| 📁 Shelf | Drop, Share > Nusa Shelf, + Add, drag keluar, buka |

Alert di notch: baterai, jaringan, Bluetooth, dan notifikasi app lain.

Ukuran notch (lebar, tebal, jarak dari atas) bisa disetel di pengaturan app.

## Catatan data
- **Markets**: Yahoo Finance (endpoint chart, tanpa key), di-poll tiap 3 dtk untuk pair terpilih dan 12 dtk untuk sisanya, hanya saat tab Markets terbuka. Hampir realtime, bukan tick-by-tick. XAUUSD memakai `XAUUSD=X` dan jatuh ke `GC=F` kalau kosong.
- **Device**: CPU load dihitung dari `/proc/stat` kalau bisa dibaca, kalau tidak dari rasio frekuensi core. GPU load dan suhu CPU/GPU dibaca dari sysfs; Android modern sering memblokirnya untuk app biasa, jadi tampil "—" (butuh root/Shizuku). Memory dan baterai selalu terbaca.
- **Weather**: pakai lokasi kasar kalau izin Location diberikan, kalau tidak default Makassar.

## Tampilan notch
- Menempel rata di tepi atas layar (jarak 0 dp), atas datar, bawah melengkung.
- Ketuk pil: player lebar (art, judul, lirik 3 baris, progress dengan sisa waktu, tombol). Warna latar mengikuti warna album.
- Tab lain (Device, Markets, Calendar, Shelf) lewat ikon kecil di strip atas panel.
- Agar menempel di tepi atas DAN bisa disentuh, nyalakan izin **Accessibility** untuk Nusa (opsional, tidak membaca layar).
  Tanpa itu, naikkan jarak notch dari atas di pengaturan sampai bisa diketuk.

## Catatan jujur
- Dibangun dari hasil bongkar installer (tanpa source asli), jadi tampilan/perilaku detail mirip, bukan identik.
- Belum pernah dikompilasi di sandbox pembuatnya. Kalau Gradle menolak sesuatu, kirim pesan error-nya.
- Drag-and-drop file langsung ke overlay tergantung izin baca URI dari app sumber. Paling andal: drop ke kartu Shelf di app Nusa (split-screen), atau Share > Nusa Shelf.
- Jarak notch dari atas bisa disetel di pengaturan.
