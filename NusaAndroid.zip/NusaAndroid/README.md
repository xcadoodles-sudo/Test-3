# Nusa untuk Android (port dari NusaSetup.exe)

"Living notch" yang melayang di tengah-atas layar, versi Android untuk Xiaomi Pad 6S Pro.
Kotlin murni, tanpa Compose, dependensi cuma `androidx.core`.

## Cara build (Android Studio)
1. Buka folder `NusaAndroid` di Android Studio (Ladybug atau lebih baru). Tunggu Gradle sync (butuh internet sekali).
2. Colok tablet (USB debugging aktif) lalu Run, atau Build > Build APK(s) dan install `app-debug.apk`.
3. Buka app Nusa, lalu beri izin dari atas ke bawah:
   - Display over other apps (wajib)
   - Notification access (musik, lirik, notif app)
   - Post notifications, Bluetooth devices
   - Battery: No restrictions, lalu tombol Xiaomi autostart (HyperOS suka mematikan service)
4. Tekan **Start notch**.

## Fitur (dipetakan dari versi Windows)
| Windows | Android |
|---|---|
| Musik (SMTC) | MediaSessionManager + tombol prev/play/next, seek |
| Lirik LRCLIB | lrclib.net, sinkron per baris |
| Pomodoro 25/5/15 | Tab Timer, hitung mundur tampil di pil |
| Water reminder | Tab Water: botol 1.5-3 L, goal, jam aktif, Drank/Refilled/Snooze/Reset |
| To-do | Tab Todo + Add/Edit Task, pengingat jam opsional |
| File shelf | Tab Shelf: drop, Share > Nusa Shelf, + Add, drag keluar, buka |
| Baterai / jaringan / Bluetooth | Alert di notch |
| Notifikasi Windows | Notifikasi app lain muncul di notch |
| Nusa Mascot, Minimal notch | Ada di pengaturan |

Tidak di-port: indikator Caps Lock, dan "Start with Windows" jadi "Start with device".

## Catatan jujur
- Dibangun dari hasil bongkar installer (tanpa source asli), jadi tampilan/perilaku detail mirip, bukan identik.
- Belum pernah dikompilasi di sandbox pembuatnya. Kalau Gradle menolak sesuatu, kirim pesan error-nya.
- Drag-and-drop file langsung ke overlay tergantung izin baca URI dari app sumber. Paling andal: drop ke kartu Shelf di app Nusa (split-screen), atau Share > Nusa Shelf.
- Jarak notch dari atas bisa disetel di pengaturan.
